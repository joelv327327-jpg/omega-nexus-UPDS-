# Omega Nexus — Plataforma Web Interactiva de Catálogo Digital Temático

**Proyecto Integrador | Diseño Web II | Gestión 2026 — Segundo Semestre**
Alineado al Objetivo de Desarrollo Sostenible **ODS 9: Industria, Innovación e Infraestructura**

Omega Nexus es una plataforma web interactiva para la **gestión y consulta de un catálogo digital temático de videojuegos**. Permite buscar, filtrar, ordenar, registrar, modificar, eliminar y valorar juegos, enriqueciendo el catálogo con datos reales consumidos desde una API pública externa, con persistencia de datos en el navegador mediante LocalStorage.

---

## 1. Tecnologías aplicadas

| Tecnología | Uso en el proyecto |
|---|---|
| HTML5 | Maquetación semántica de las 6 páginas de la plataforma |
| CSS3 | Estilos propios (`css/custom.css`) sobre la plantilla base |
| Bootstrap 4.2 | Framework CSS: grilla responsive, modal CRUD, formularios |
| JavaScript (ES6+) | Manipulación del DOM, eventos, lógica de negocio |
| jQuery 3.2 | Selección/manipulación del DOM y peticiones AJAX |
| AJAX + JSON | Consumo de la API pública FreeToGame (`$.ajax`, `dataType: json`) |
| LocalStorage | Persistencia del catálogo, favoritos, mensajes y suscripciones |

## 2. Estructura del proyecto

```
Omega-Nexus/
├── index.html          → Inicio: destacados, últimas incorporaciones, estadísticas
├── games.html          → Catálogo: búsqueda, filtros, ordenamiento y CRUD
├── game-single.html    → Vista de detalle dinámica (?id=identificador)
├── review.html         → Reseñas ordenadas por valoración con filtro mínimo
├── blog.html           → Novedades: últimos juegos agregados + buscador lateral
├── contact.html        → Contacto: formulario funcional validado
├── css/
│   ├── style.css       → Estilos base de la plantilla
│   └── custom.css      → Estilos propios de la plataforma
├── js/
│   ├── data.js         → Catálogo semilla en formato JSON (respaldo sin conexión)
│   ├── app.js          → Lógica principal: Store, API, render, CRUD, filtros
│   └── main.js         → Comportamientos de la plantilla (slider, menú, etc.)
└── img/                → Recursos gráficos
```

## 3. Cumplimiento de los requerimientos (Perfil del Proyecto)

### Requerimientos funcionales

| Requerimiento | Implementación |
|---|---|
| Búsqueda de elementos | Buscador en vivo por nombre/palabra clave en `games.html` (título, descripción y desarrollador) y buscador lateral en `blog.html` |
| Filtros por categoría u otro criterio | Filtros por género y plataforma alimentados dinámicamente desde el catálogo |
| Organización por categorías | Widgets de categorías en Inicio/Novedades que enlazan al catálogo filtrado (`?genero=`) |
| Vista de detalle | `game-single.html?id=` con ficha técnica, valoración, relacionados y acciones CRUD |
| Navegación clara entre secciones | Menú principal y pie de página consistentes en las 6 páginas + breadcrumbs |
| Consumo de al menos una API externa | API pública [FreeToGame](https://www.freetogame.com/api) vía AJAX; botón "Sincronizar API" y sincronización automática al iniciar |
| Persistencia con LocalStorage | Claves: `on_catalogo`, `on_favoritos`, `on_mensajes`, `on_boletin` |
| Manejo de datos JSON | Catálogo semilla (`data.js`), respuestas de la API y almacenamiento local en JSON |
| Diseño responsive | Grilla Bootstrap 4 + media queries de la plantilla (móvil, tablet, escritorio) |
| Framework CSS | Bootstrap 4.2 incluido y utilizado (grilla, modal, formularios, utilidades) |

**CRUD completo:** registro (modal "Agregar juego"), modificación (botón editar), eliminación (con confirmación) y búsqueda de contenidos del catálogo.

### Requerimientos no funcionales

- Interfaz coherente con identidad propia (paleta y componentes Omega Nexus).
- Usabilidad: navegación intuitiva, estados vacíos y notificaciones (toasts).
- Accesibilidad básica: atributos `alt` descriptivos, etiquetas `label`/`aria-label`, foco visible, contraste adecuado.
- Rendimiento: renderizado dinámico sin recargas, imágenes con respaldo automático.
- Código organizado y comentado en módulos (Store / API / Render / CRUD).
- Repositorio Git con historial de commits que evidencia el desarrollo.

## 4. Limitaciones respetadas

Sin backend propio, sin bases de datos relacionales, sin autenticación real, sin pasarelas de pagos, sin apps nativas y sin panel administrativo complejo, conforme a la sección 7 del perfil del proyecto.

## 5. Puesta en marcha

1. Descargar o clonar el repositorio.
2. Abrir `index.html` en cualquier navegador moderno (doble clic o con la extensión *Live Server* de VS Code).
3. La primera carga inicializa el catálogo con datos semilla y sincroniza automáticamente con la API externa (requiere conexión a internet; sin conexión funciona igualmente con los datos locales).

> Nota: al ser una aplicación 100% FrontEnd, los datos se almacenan únicamente en el navegador actual. Para restablecer el catálogo original puede limpiarse el LocalStorage desde las herramientas de desarrollador (Aplicación → Almacenamiento local → Eliminar `on_catalogo`).

## 6. Manual de usuario

### Explorar el catálogo
- Ingresa a **Catálogo** para ver todos los juegos.
- Usa el **buscador** para encontrar juegos por nombre o palabra clave; los resultados se actualizan mientras escribes.
- Filtra por **categoría** o **plataforma** con los menús desplegables.
- Ordena por nombre (A-Z / Z-A), valoración (mayor/menor) o fecha (recientes/antiguos).

### Registrar un juego nuevo
1. En el catálogo pulsa **Agregar juego**.
2. Completa el formulario (título, categoría y plataforma son obligatorios).
3. Pulsa **Guardar juego**: aparecerá en la grilla y quedará guardado en tu navegador.

### Modificar o eliminar un juego
- En cada tarjeta usa el ícono de **lápiz** para modificar sus datos o el de **basurero** para eliminarlo (pedirá confirmación).
- También puedes hacerlo desde la ficha de detalle del juego.

### Favoritos
- Marca juegos con el ícono de **corazón**; quedan guardados en tu navegador incluso si cierras la página.

### Reseñas y novedades
- En **Reseñas** verás los juegos ordenados por valoración; puedes filtrar por puntaje mínimo.
- En **Novedades** aparecen los últimos juegos incorporados al catálogo.

### Contacto y boletín
- En **Contacto**, completa el formulario y envía: tu mensaje queda registrado y verás una confirmación.
- Suscríbete al boletín ingresando tu correo en la parte inferior de cualquier página.

---

*Facultad de Ingeniería — Ingeniería de Sistemas | Asignatura: Diseño Web II | Docente: Lic. Toro Carlos | Cochabamba, Bolivia*
