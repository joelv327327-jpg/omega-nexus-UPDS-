/* ============================================================
   OMEGA NEXUS - Catálogo Digital Temático de Videojuegos
   Proyecto Integrador - Diseño Web II (ODS 9)
   ------------------------------------------------------------
   data.js
   Catálogo semilla en formato JSON.
   Se carga como datos iniciales del catálogo la primera vez que
   se abre la plataforma y actúa como respaldo (fallback) cuando
   la API pública externa no está disponible (sin conexión).
   ============================================================ */

/* Esquema de cada elemento del catálogo:
   {
     id:            Number  -> Identificador único del juego
     titulo:        String  -> Nombre del juego
     genero:        String  -> Categoría temática (Acción, RPG, etc.)
     plataforma:    String  -> Plataforma principal (PC, PlayStation...)
     fecha:         String  -> Fecha de lanzamiento (ISO: AAAA-MM-DD)
     valoracion:    Number  -> Valoración de 0 a 5 estrellas
     descripcion:   String  -> Descripción corta del juego
     desarrollador: String  -> Estudio desarrollador
     imagen:        String  -> Ruta o URL de la imagen de portada
     origen:        String  -> "local" (semilla/usuario) | "api" (API externa)
   } */

const SEED_CATALOGO = [
	{
		id: 1,
		titulo: "Zombie Apocalipse 2",
		genero: "Terror",
		plataforma: "PC",
		fecha: "2019-03-15",
		valoracion: 4.5,
		descripcion: "Sobrevive a una horda infinita de zombis en un mundo abierto post-apocalíptico. Mejora tu arsenal, forma alianzas y descubre el origen del brote en esta secuela llena de tensión y acción.",
		desarrollador: "Nexus Studios",
		imagen: "img/games/1.jpg",
		origen: "local"
	},
	{
		id: 2,
		titulo: "Dooms Day",
		genero: "Acción",
		plataforma: "PlayStation",
		fecha: "2020-07-22",
		valoracion: 4.0,
		descripcion: "El juicio final ha llegado. Comanda a los últimos resistentes de la humanidad contra máquinas ancestrales en un shooter frenético con física destructible por completo.",
		desarrollador: "Red Line Games",
		imagen: "img/games/2.jpg",
		origen: "local"
	},
	{
		id: 3,
		titulo: "The Hurricane",
		genero: "Aventura",
		plataforma: "Xbox",
		fecha: "2018-11-02",
		valoracion: 3.5,
		descripcion: "Una aventura narrativa donde controlas el clima para resolver puzzles y avanzar. Explora islas tropicales azotadas por tormentas y libera a sus habitantes de una antigua maldición.",
		desarrollador: "Blue Wave Interactive",
		imagen: "img/games/3.jpg",
		origen: "local"
	},
	{
		id: 4,
		titulo: "Star Wars: Galaxy Rise",
		genero: "RPG",
		plataforma: "PC",
		fecha: "2021-05-04",
		valoracion: 4.8,
		descripcion: "Un RPG espacial de mundo abierto. Crea tu propio personaje, elige entre el lado luminoso u oscuro, pilota naves legendarias y decide el destino de toda una galaxia.",
		desarrollador: "Orbit Forge",
		imagen: "img/games/4.jpg",
		origen: "local"
	},
	{
		id: 5,
		titulo: "Candy Land Rush",
		genero: "Puzzle",
		plataforma: "Móvil",
		fecha: "2022-01-18",
		valoracion: 3.8,
		descripcion: "Combina dulces en cascadas infinitas de color. Cientos de niveles con mecánicas únicas, modos contrarreloj y clasificaciones globales para competir con tus amigos.",
		desarrollador: "Sweet Bit Studio",
		imagen: "img/games/5.jpg",
		origen: "local"
	},
	{
		id: 6,
		titulo: "E.T. The Extra Odyssey",
		genero: "Aventura",
		plataforma: "Nintendo Switch",
		fecha: "2019-09-30",
		valoracion: 3.2,
		descripcion: "Ayuda a un pequeño extraterrestre a volver a su hogar explorando la Tierra rural de los años 80. Un clásico renovado con gráficos modernos y nuevos finales secretos.",
		desarrollador: "Retro Pulse",
		imagen: "img/games/6.jpg",
		origen: "local"
	},
	{
		id: 7,
		titulo: "Turbo Circuit Legends",
		genero: "Carreras",
		plataforma: "PlayStation",
		fecha: "2023-02-14",
		valoracion: 4.2,
		descripcion: "Circuitos urbanos, derrapes extremos y autos personalizables al detalle. Compite online en temporadas clasificatorias o domina el modo carrera en solitario.",
		desarrollador: "Velocity Works",
		imagen: "img/games/7.jpg",
		origen: "local"
	},
	{
		id: 8,
		titulo: "Empire Strategy X",
		genero: "Estrategia",
		plataforma: "PC",
		fecha: "2020-10-08",
		valoracion: 4.6,
		descripcion: "Construye tu imperio desde la edad de piedra hasta la era espacial. Diplomacia, comercio y guerra total por turnos contra IA adaptativa o hasta 8 jugadores en línea.",
		desarrollador: "Iron Crown Games",
		imagen: "img/games/8.jpg",
		origen: "local"
	},
	{
		id: 9,
		titulo: "Final Apocalipse 2.1",
		genero: "Shooter",
		plataforma: "Xbox",
		fecha: "2021-12-01",
		valoracion: 4.4,
		descripcion: "El shooter multijugador más competitivo del momento. Modos 5v5, battle royale de 100 jugadores y un sistema de progresión de armas sin precedentes.",
		desarrollador: "Nexus Studios",
		imagen: "img/games/9.jpg",
		origen: "local"
	}
];

/* Géneros disponibles para poblar dinámicamente los filtros
   y el formulario de registro/edición del catálogo. */
const GENEROS_BASE = [
	"Acción", "Aventura", "Carreras", "Deportes",
	"Estrategia", "Puzzle", "RPG", "Shooter", "Terror"
];

/* Plataformas disponibles para filtros y formulario. */
const PLATAFORMAS_BASE = [
	"PC", "PlayStation", "Xbox", "Nintendo Switch", "Móvil"
];
