/* ============================================================
   OMEGA NEXUS - Catálogo Digital Temático de Videojuegos
   Proyecto Integrador - Diseño Web II (ODS 9)
   ------------------------------------------------------------
   app.js
   Lógica principal de la plataforma:
     - Store  : persistencia de datos en LocalStorage (JSON)
     - API    : consumo de API pública externa (AJAX + JSON)
     - Render : generación dinámica del DOM
     - CRUD   : registro, modificación y eliminación de juegos
     - Búsqueda, filtros por categoría y ordenamiento
   ============================================================ */

'use strict';

/* ============================================================
   1. MÓDULO STORE - Persistencia en LocalStorage
   Toda la información se guarda en formato JSON mediante
   JSON.stringify() y se recupera con JSON.parse().
   ============================================================ */
const Store = {
	/* Claves utilizadas dentro de LocalStorage */
	CLAVE_CATALOGO: 'on_catalogo',
	CLAVE_FAVORITOS: 'on_favoritos',
	CLAVE_MENSAJES: 'on_mensajes',
	CLAVE_BOLETIN: 'on_boletin',

	/* ---------- Catálogo ---------- */

	/* Devuelve el arreglo de juegos guardado (o [] si no existe) */
	obtenerCatalogo: function () {
		try {
			return JSON.parse(localStorage.getItem(this.CLAVE_CATALOGO)) || [];
		} catch (e) {
			return [];
		}
	},

	/* Guarda el arreglo completo del catálogo en LocalStorage */
	guardarCatalogo: function (lista) {
		localStorage.setItem(this.CLAVE_CATALOGO, JSON.stringify(lista));
	},

	/* Inicializa el catálogo la primera vez que se abre la web */
	inicializarCatalogo: function () {
		if (!localStorage.getItem(this.CLAVE_CATALOGO)) {
			this.guardarCatalogo(SEED_CATALOGO);
		}
	},

	/* Busca un juego por su id (comparación segura como texto) */
	buscarPorId: function (id) {
		return this.obtenerCatalogo().find(function (j) {
			return String(j.id) === String(id);
		});
	},

	/* CREATE - Registra un nuevo juego en el catálogo */
	agregar: function (juego) {
		const lista = this.obtenerCatalogo();
		/* Se genera un id único basado en la marca de tiempo */
		juego.id = Date.now();
		juego.origen = 'local';
		lista.push(juego);
		this.guardarCatalogo(lista);
		return juego;
	},

	/* UPDATE - Modifica los datos de un juego existente */
	actualizar: function (juego) {
		const lista = this.obtenerCatalogo();
		const indice = lista.findIndex(function (j) {
			return String(j.id) === String(juego.id);
		});
		if (indice === -1) return null;
		juego.origen = lista[indice].origen; /* se conserva el origen */
		lista[indice] = juego;
		this.guardarCatalogo(lista);
		return juego;
	},

	/* DELETE - Elimina un juego del catálogo por su id */
	eliminar: function (id) {
		const lista = this.obtenerCatalogo().filter(function (j) {
			return String(j.id) !== String(id);
		});
		this.guardarCatalogo(lista);
	},

	/* ---------- Favoritos (innovación: interacción extra) ---------- */

	obtenerFavoritos: function () {
		try {
			return JSON.parse(localStorage.getItem(this.CLAVE_FAVORITOS)) || [];
		} catch (e) {
			return [];
		}
	},

	esFavorito: function (id) {
		return this.obtenerFavoritos().some(function (f) {
			return String(f) === String(id);
		});
	},

	alternarFavorito: function (id) {
		let favs = this.obtenerFavoritos();
		if (this.esFavorito(id)) {
			favs = favs.filter(function (f) { return String(f) !== String(id); });
		} else {
			favs.push(String(id));
		}
		localStorage.setItem(this.CLAVE_FAVORITOS, JSON.stringify(favs));
		return this.esFavorito(id);
	},

	/* ---------- Mensajes de contacto y boletín ---------- */

	agregarMensaje: function (mensaje) {
		const mensajes = JSON.parse(localStorage.getItem(this.CLAVE_MENSAJES) || '[]');
		mensajes.push(mensaje);
		localStorage.setItem(this.CLAVE_MENSAJES, JSON.stringify(mensajes));
	},

	agregarBoletin: function (email) {
		const correos = JSON.parse(localStorage.getItem(this.CLAVE_BOLETIN) || '[]');
		if (!correos.includes(email)) correos.push(email);
		localStorage.setItem(this.CLAVE_BOLETIN, JSON.stringify(correos));
	}
};

/* ============================================================
   2. MÓDULO API - Consumo de API pública externa (AJAX + JSON)
   Fuente: FreeToGame (https://www.freetogame.com/api)
   Enriquece el catálogo local con juegos gratuitos reales.
   ============================================================ */
const API = {
	URL: 'https://www.freetogame.com/api/games',

	/* Convierte un elemento de la API al esquema interno del catálogo.
	   Nota: la API no provee valoración, por lo que se genera una
	   valoración determinística a partir del id (estable entre cargas). */
	mapear: function (item) {
		return {
			id: 'api-' + item.id,
			titulo: item.title,
			genero: item.genre,
			plataforma: item.platform,
			fecha: item.release_date,
			valoracion: Math.round(((item.id % 20) / 10 + 3) * 10) / 10,
			descripcion: item.short_description,
			desarrollador: item.developer || 'Desconocido',
			imagen: item.thumbnail,
			juego_url: item.game_url || '',
			origen: 'api'
		};
	},

	/* Descarga los juegos mediante AJAX ($ .ajax devuelve JSON) y los
	   fusiona con el catálogo local evitando duplicados por título. */
	sincronizar: function () {
		return $.ajax({
			url: this.URL,
			dataType: 'json',
			method: 'GET'
		}).then(function (datos) {
			const lista = Store.obtenerCatalogo();
			const titulosExistentes = lista.map(function (j) {
				return j.titulo.toLowerCase();
			});
			let nuevos = 0;

			datos.forEach(function (item) {
				const juego = API.mapear(item);
				if (!titulosExistentes.includes(juego.titulo.toLowerCase())) {
					lista.push(juego);
					titulosExistentes.push(juego.titulo.toLowerCase());
					nuevos++;
				}
			});

			Store.guardarCatalogo(lista);
			return nuevos;
		});
	}
};

/* ============================================================
   3. UTILIDADES GENERALES
   ============================================================ */

/* Escapa caracteres HTML para evitar inyección de código (XSS)
   cuando se muestra contenido ingresado por el usuario. */
function escaparHTML(texto) {
	return String(texto == null ? '' : texto)
		.replace(/&/g, '&amp;').replace(/</g, '&lt;')
		.replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/* Formatea una fecha ISO (AAAA-MM-DD) al formato DD/MM/AAAA */
function formatearFecha(iso) {
	if (!iso) return 'Sin fecha';
	const partes = String(iso).split('-');
	if (partes.length !== 3) return iso;
	return partes[2] + '/' + partes[1] + '/' + partes[0];
}

/* Genera las estrellas (Font Awesome) según la valoración 0-5 */
function generarEstrellas(valoracion) {
	let html = '';
	for (let i = 1; i <= 5; i++) {
		if (valoracion >= i) {
			html += '<i class="fa fa-star" aria-hidden="true"></i>';
		} else if (valoracion >= i - 0.5) {
			html += '<i class="fa fa-star-half-o" aria-hidden="true"></i>';
		} else {
			html += '<i class="fa fa-star-o" aria-hidden="true"></i>';
		}
	}
	return html;
}

/* Lee un parámetro de la URL (por ejemplo ?id=5 o ?genero=RPG) */
function parametroURL(nombre) {
	return new URLSearchParams(window.location.search).get(nombre);
}

/* Notificación visual temporal (toast) para feedback al usuario */
function mostrarToast(mensaje, tipo) {
	const $toast = $(
		'<div class="on-toast ' + (tipo || 'exito') + '" role="status" aria-live="polite">' +
		escaparHTML(mensaje) + '</div>'
	);
	$('body').append($toast);
	setTimeout(function () { $toast.addClass('visible'); }, 10);
	setTimeout(function () {
		$toast.removeClass('visible');
		setTimeout(function () { $toast.remove(); }, 400);
	}, 2600);
}

/* Imagen de respaldo si la portada externa falla (modo sin conexión) */
const IMAGEN_RESPALDO = 'img/games/big.jpg';

/* Construye la tarjeta de un juego para el catálogo (games.html) */
function tarjetaJuego(juego) {
	const esFav = Store.esFavorito(juego.id);
	return '' +
	'<div class="col-lg-4 col-md-6">' +
		'<div class="game-item on-card" data-id="' + escaparHTML(juego.id) + '">' +
			'<img src="' + escaparHTML(juego.imagen) + '" alt="Portada del juego ' + escaparHTML(juego.titulo) + '"' +
				' onerror="this.onerror=null;this.src=\'' + IMAGEN_RESPALDO + '\'">' +
			'<span class="on-badge">' + escaparHTML(juego.genero) + '</span>' +
			'<h5>' + escaparHTML(juego.titulo) + '</h5>' +
			'<div class="on-card-meta">' +
				'<span class="on-stars" aria-label="Valoración ' + juego.valoracion + ' de 5">' +
					generarEstrellas(Number(juego.valoracion) || 0) +
					' <b>' + Number(juego.valoracion).toFixed(1) + '</b></span>' +
				'<span class="on-fecha"><i class="fa fa-calendar" aria-hidden="true"></i> ' +
					formatearFecha(juego.fecha) + '</span>' +
			'</div>' +
			'<p class="on-desc">' + escaparHTML(juego.descripcion) + '</p>' +
			'<div class="on-card-actions">' +
				'<a href="game-single.html?id=' + encodeURIComponent(juego.id) + '" class="read-more">Ver detalle' +
					' <img src="img/icons/double-arrow.png" alt=""/></a>' +
				'<button type="button" class="on-icon-btn on-fav' + (esFav ? ' activo' : '') + '"' +
					' data-accion="favorito" aria-label="Marcar como favorito"' +
					' title="Favorito"><i class="fa fa-heart" aria-hidden="true"></i></button>' +
				'<button type="button" class="on-icon-btn" data-accion="editar"' +
					' aria-label="Editar juego" title="Editar"><i class="fa fa-pencil" aria-hidden="true"></i></button>' +
				'<button type="button" class="on-icon-btn on-peligro" data-accion="eliminar"' +
					' aria-label="Eliminar juego" title="Eliminar"><i class="fa fa-trash" aria-hidden="true"></i></button>' +
			'</div>' +
		'</div>' +
	'</div>';
}

/* Rellena un <select> con opciones sin repetir valores.
   Si se indica textoVacio se agrega como primera opción (placeholder). */
function llenarSelect($select, valores, valorActual, textoVacio) {
	$select.find('option').remove();
	if (textoVacio) {
		$select.append('<option value="">' + escaparHTML(textoVacio) + '</option>');
	}
	valores.forEach(function (v) {
		$select.append('<option value="' + escaparHTML(v) + '">' + escaparHTML(v) + '</option>');
	});
	if (valorActual) $select.val(valorActual);
}

/* Obtiene la lista única de géneros presentes en el catálogo */
function generosDelCatalogo() {
	const set = new Set(GENEROS_BASE);
	Store.obtenerCatalogo().forEach(function (j) { if (j.genero) set.add(j.genero); });
	return Array.from(set).sort();
}

/* Obtiene la lista única de plataformas presentes en el catálogo */
function plataformasDelCatalogo() {
	const set = new Set(PLATAFORMAS_BASE);
	Store.obtenerCatalogo().forEach(function (j) { if (j.plataforma) set.add(j.plataforma); });
	return Array.from(set).sort();
}

/* ============================================================
   4. FORMULARIO DE ALTA / EDICIÓN (CRUD) - Modal Bootstrap
   ============================================================ */

/* Abre el modal vacío (registro) o precargado (edición) */
function abrirModalJuego(juego) {
	const $form = $('#form-juego');
	$form.removeClass('was-validated')[0].reset();
	$('#juego-id').val(juego ? juego.id : '');
	llenarSelect($('#juego-genero'), generosDelCatalogo(), juego ? juego.genero : '', 'Selecciona una categoría...');
	llenarSelect($('#juego-plataforma'), plataformasDelCatalogo(), juego ? juego.plataforma : '', 'Selecciona una plataforma...');
	if (juego) {
		$('#modal-juego-titulo').text('Modificar juego');
		$('#juego-titulo').val(juego.titulo);
		$('#juego-fecha').val(juego.fecha);
		$('#juego-valoracion').val(juego.valoracion);
		$('#juego-desarrollador').val(juego.desarrollador);
		$('#juego-imagen').val(juego.imagen);
		$('#juego-descripcion').val(juego.descripcion);
	} else {
		$('#modal-juego-titulo').text('Registrar nuevo juego');
	}
	$('#modal-juego').modal('show');
}

/* Valida y guarda el formulario del modal (alta o modificación) */
function guardarFormularioJuego(evento) {
	evento.preventDefault();
	const $form = $('#form-juego');

	/* Validación nativa HTML5 + clase visual de Bootstrap */
	if (!$form[0].checkValidity()) {
		$form.addClass('was-validated');
		return;
	}

	const id = $('#juego-id').val();
	const datos = {
		titulo: $.trim($('#juego-titulo').val()),
		genero: $('#juego-genero').val(),
		plataforma: $('#juego-plataforma').val(),
		fecha: $('#juego-fecha').val(),
		valoracion: Number($('#juego-valoracion').val()),
		descripcion: $.trim($('#juego-descripcion').val()),
		desarrollador: $.trim($('#juego-desarrollador').val()) || 'Independiente',
		imagen: $.trim($('#juego-imagen').val()) || IMAGEN_RESPALDO
	};

	if (id) {
		/* UPDATE: conserva campos adicionales del juego original */
		const original = Store.buscarPorId(id);
		datos.id = original.id;
		datos.juego_url = original.juego_url || '';
		Store.actualizar(datos);
		mostrarToast('Juego modificado correctamente.');
	} else {
		/* CREATE */
		Store.agregar(datos);
		mostrarToast('Juego registrado correctamente.');
	}

	$('#modal-juego').modal('hide');

	/* Si estamos en el catálogo, se refresca la grilla */
	if (window.PaginaActual === 'catalogo') renderizarCatalogo();
	if (window.PaginaActual === 'detalle') renderizarDetalle();
	if (window.PaginaActual === 'resenas') renderizarResenas();
	if (window.PaginaActual === 'novedades') renderizarNovedades();
}

/* Elimina un juego pidiendo confirmación previa al usuario */
function eliminarJuego(id) {
	const juego = Store.buscarPorId(id);
	if (!juego) return;
	if (!confirm('¿Estás seguro de eliminar "' + juego.titulo + '" del catálogo?')) return;
	Store.eliminar(id);
	mostrarToast('Juego eliminado del catálogo.');

	if (window.PaginaActual === 'catalogo') renderizarCatalogo();
	if (window.PaginaActual === 'detalle') window.location.href = 'games.html';
	if (window.PaginaActual === 'resenas') renderizarResenas();
	if (window.PaginaActual === 'novedades') renderizarNovedades();
}

/* Delegación global de eventos para botones favorito/editar/eliminar
   (funciona aunque las tarjetas se vuelvan a renderizar) */
$(document).on('click', '.on-card [data-accion]', function () {
	const accion = $(this).data('accion');
	const id = $(this).closest('.on-card').data('id');
	if (accion === 'favorito') {
		const activo = Store.alternarFavorito(id);
		$(this).toggleClass('activo', activo);
		mostrarToast(activo ? 'Agregado a favoritos.' : 'Quitado de favoritos.');
	}
	if (accion === 'editar') abrirModalJuego(Store.buscarPorId(id));
	if (accion === 'eliminar') eliminarJuego(id);
});

/* ============================================================
   5. PÁGINA CATÁLOGO (games.html)
   Búsqueda, filtros, ordenamiento y grilla dinámica
   ============================================================ */

/* Estado actual de los criterios de búsqueda/filtrado/orden */
const estadoCatalogo = {
	busqueda: '',
	genero: '',
	plataforma: '',
	orden: 'nombre-az'
};

/* Aplica búsqueda + filtros + orden sobre el catálogo completo */
function filtrarCatalogo() {
	let lista = Store.obtenerCatalogo();

	/* Búsqueda por nombre o palabra clave (título y descripción) */
	if (estadoCatalogo.busqueda) {
		const termino = estadoCatalogo.busqueda.toLowerCase();
		lista = lista.filter(function (j) {
			return j.titulo.toLowerCase().includes(termino) ||
				(j.descripcion || '').toLowerCase().includes(termino) ||
				(j.desarrollador || '').toLowerCase().includes(termino);
		});
	}

	/* Filtro por género (categoría) */
	if (estadoCatalogo.genero) {
		lista = lista.filter(function (j) { return j.genero === estadoCatalogo.genero; });
	}

	/* Filtro por plataforma */
	if (estadoCatalogo.plataforma) {
		lista = lista.filter(function (j) { return j.plataforma === estadoCatalogo.plataforma; });
	}

	/* Ordenamiento según el criterio elegido */
	const ordenadores = {
		'nombre-az': function (a, b) { return a.titulo.localeCompare(b.titulo, 'es'); },
		'nombre-za': function (a, b) { return b.titulo.localeCompare(a.titulo, 'es'); },
		'valoracion-desc': function (a, b) { return b.valoracion - a.valoracion; },
		'valoracion-asc': function (a, b) { return a.valoracion - b.valoracion; },
		'fecha-reciente': function (a, b) { return String(b.fecha).localeCompare(String(a.fecha)); },
		'fecha-antigua': function (a, b) { return String(a.fecha).localeCompare(String(b.fecha)); }
	};
	lista = lista.slice().sort(ordenadores[estadoCatalogo.orden] || ordenadores['nombre-az']);

	return lista;
}

/* Dibuja la grilla de tarjetas según el estado actual */
function renderizarCatalogo() {
	const resultados = filtrarCatalogo();
	const $grilla = $('#grilla-catalogo');
	const $vacio = $('#catalogo-vacio');

	$grilla.empty();
	resultados.forEach(function (juego) {
		$grilla.append(tarjetaJuego(juego));
	});

	/* Contador de resultados y mensaje de estado vacío */
	$('#contador-resultados').text(
		resultados.length + (resultados.length === 1 ? ' juego encontrado' : ' juegos encontrados')
	);
	$vacio.toggleClass('d-none', resultados.length > 0);
}

function initCatalogo() {
	window.PaginaActual = 'catalogo';

	/* Se aceptan parámetros de URL (?q= y ?genero=) desde otras páginas */
	const q = parametroURL('q');
	const generoURL = parametroURL('genero');
	if (q) { estadoCatalogo.busqueda = q; $('#buscador-catalogo').val(q); }
	if (generoURL) { estadoCatalogo.genero = generoURL; }

	/* Se llenan los filtros con géneros/plataformas reales del catálogo */
	llenarSelect($('#filtro-genero'), generosDelCatalogo(), estadoCatalogo.genero, 'Todas las categorías');
	llenarSelect($('#filtro-plataforma'), plataformasDelCatalogo(), '', 'Todas las plataformas');

	/* Eventos de búsqueda (en vivo) y filtros */
	$('#buscador-catalogo').on('input', function () {
		estadoCatalogo.busqueda = $(this).val();
		renderizarCatalogo();
	});
	$('#filtro-genero').on('change', function () {
		estadoCatalogo.genero = $(this).val();
		renderizarCatalogo();
	});
	$('#filtro-plataforma').on('change', function () {
		estadoCatalogo.plataforma = $(this).val();
		renderizarCatalogo();
	});
	$('#orden-catalogo').on('change', function () {
		estadoCatalogo.orden = $(this).val();
		renderizarCatalogo();
	});

	/* Botón de registro de nuevos juegos (CREATE del CRUD) */
	$('#btn-agregar-juego').on('click', function () { abrirModalJuego(null); });

	/* Botón para re-sincronizar manualmente con la API externa */
	$('#btn-sincronizar').on('click', function () {
		const $btn = $(this).prop('disabled', true).text('Sincronizando...');
		API.sincronizar()
			.done(function (nuevos) {
				llenarSelect($('#filtro-genero'), generosDelCatalogo(), estadoCatalogo.genero, 'Todas las categorías');
				llenarSelect($('#filtro-plataforma'), plataformasDelCatalogo(), estadoCatalogo.plataforma, 'Todas las plataformas');
				renderizarCatalogo();
				mostrarToast(nuevos > 0
					? nuevos + ' juegos importados desde la API.'
					: 'Catálogo ya sincronizado con la API.');
			})
			.fail(function () {
				mostrarToast('No se pudo conectar con la API externa.', 'error');
			})
			.always(function () {
				$btn.prop('disabled', false).html('<i class="fa fa-refresh" aria-hidden="true"></i> Sincronizar API');
			});
	});

	renderizarCatalogo();
}

/* ============================================================
   6. PÁGINA DETALLE (game-single.html) - Vista ?id=
   ============================================================ */

function renderizarDetalle() {
	const id = parametroURL('id');
	const juego = id ? Store.buscarPorId(id) : null;

	/* Si no existe el juego solicitado se muestra el estado vacío */
	if (!juego) {
		$('#detalle-contenido').addClass('d-none');
		$('#detalle-vacio').removeClass('d-none');
		return;
	}

	document.title = juego.titulo + ' | Omega Nexus';

	$('#detalle-imagen').attr({
		src: juego.imagen,
		alt: 'Portada del juego ' + juego.titulo
	}).on('error', function () {
		$(this).off('error').attr('src', IMAGEN_RESPALDO);
	});
	$('#detalle-titulo').text(juego.titulo);
	$('#detalle-meta').html(
		formatearFecha(juego.fecha) + ' &nbsp;/&nbsp; en <a href="games.html?genero=' +
		encodeURIComponent(juego.genero) + '">' + escaparHTML(juego.genero) + '</a>'
	);
	$('#detalle-descripcion').text(juego.descripcion);

	/* Ficha técnica del juego */
	$('#detalle-ficha').html(
		'<li>Género<span>' + escaparHTML(juego.genero) + '</span></li>' +
		'<li>Plataforma<span>' + escaparHTML(juego.plataforma) + '</span></li>' +
		'<li>Desarrollador<span>' + escaparHTML(juego.desarrollador) + '</span></li>' +
		'<li>Lanzamiento<span>' + formatearFecha(juego.fecha) + '</span></li>' +
		'<li>Origen<span>' + (juego.origen === 'api' ? 'API externa' : 'Catálogo local') + '</span></li>'
	);

	/* Valoración general con estrellas */
	$('#detalle-rating').html(
		'<h5><i>Valoración</i><span>' + Number(juego.valoracion).toFixed(1) + '</span> / 5</h5>' +
		'<div class="on-stars on-stars-lg">' + generarEstrellas(Number(juego.valoracion)) + '</div>'
	);

	/* Enlace externo solo para juegos provenientes de la API */
	$('#detalle-jugar').toggleClass('d-none', !juego.juego_url)
		.attr('href', juego.juego_url || '#');

	/* Botones de acción (CRUD) y favorito */
	$('#btn-editar-detalle').off('click').on('click', function () { abrirModalJuego(juego); });
	$('#btn-eliminar-detalle').off('click').on('click', function () { eliminarJuego(juego.id); });
	const esFav = Store.esFavorito(juego.id);
	$('#btn-favorito-detalle')
		.toggleClass('activo', esFav)
		.find('span').text(esFav ? 'En favoritos' : 'Agregar a favoritos')
		.end().off('click').on('click', function () {
			const activo = Store.alternarFavorito(juego.id);
			$(this).toggleClass('activo', activo)
				.find('span').text(activo ? 'En favoritos' : 'Agregar a favoritos');
			mostrarToast(activo ? 'Agregado a favoritos.' : 'Quitado de favoritos.');
		});

	/* Juegos relacionados: mismo género, excluyendo el actual (máx. 3) */
	const relacionados = Store.obtenerCatalogo()
		.filter(function (j) { return j.genero === juego.genero && String(j.id) !== String(juego.id); })
		.slice(0, 3);
	const $rel = $('#detalle-relacionados').empty();
	if (relacionados.length) {
		$('#detalle-relacionados-bloque').removeClass('d-none');
		relacionados.forEach(function (r) {
			$rel.append(
				'<div class="tw-item">' +
					'<div class="tw-thumb"><img src="' + escaparHTML(r.imagen) + '"' +
						' alt="Portada de ' + escaparHTML(r.titulo) + '"' +
						' onerror="this.onerror=null;this.src=\'' + IMAGEN_RESPALDO + '\'"></div>' +
					'<div class="tw-text"><div class="tw-meta">' + escaparHTML(r.genero) + '</div>' +
					'<h5><a href="game-single.html?id=' + encodeURIComponent(r.id) + '">' +
						escaparHTML(r.titulo) + '</a></h5></div>' +
				'</div>'
			);
		});
	} else {
		$('#detalle-relacionados-bloque').addClass('d-none');
	}
}

function initDetalle() {
	window.PaginaActual = 'detalle';
	renderizarDetalle();
}

/* ============================================================
   7. PÁGINA RESEÑAS (review.html) - Ordenadas por valoración
   ============================================================ */

const estadoResenas = { minimo: 0 };

function renderizarResenas() {
	let lista = Store.obtenerCatalogo();

	/* Filtro por valoración mínima */
	lista = lista.filter(function (j) { return Number(j.valoracion) >= estadoResenas.minimo; });

	/* Siempre ordenadas de mayor a menor valoración */
	lista.sort(function (a, b) { return b.valoracion - a.valoracion; });

	const $cont = $('#lista-resenas').empty();
	if (!lista.length) {
		$cont.html('<p class="text-white">No hay reseñas con ese criterio de valoración.</p>');
		return;
	}

	lista.forEach(function (juego) {
		$cont.append(
			'<div class="review-item on-card" data-id="' + escaparHTML(juego.id) + '">' +
				'<div class="row">' +
					'<div class="col-lg-4">' +
						'<div class="review-pic">' +
							'<img src="' + escaparHTML(juego.imagen) + '" alt="Portada de ' + escaparHTML(juego.titulo) + '"' +
								' onerror="this.onerror=null;this.src=\'' + IMAGEN_RESPALDO + '\'">' +
						'</div>' +
					'</div>' +
					'<div class="col-lg-8">' +
						'<div class="review-content text-box text-white">' +
							'<div class="rating"><h5><i>Valoración</i><span>' +
								Number(juego.valoracion).toFixed(1) + '</span> / 5</h5></div>' +
							'<div class="top-meta">' + formatearFecha(juego.fecha) + ' / en ' +
								'<a href="games.html?genero=' + encodeURIComponent(juego.genero) + '">' +
								escaparHTML(juego.genero) + '</a></div>' +
							'<h3>' + escaparHTML(juego.titulo) + '</h3>' +
							'<p>' + escaparHTML(juego.descripcion) + '</p>' +
							'<div class="on-card-actions">' +
								'<a href="game-single.html?id=' + encodeURIComponent(juego.id) +
									'" class="read-more">Leer reseña completa <img src="img/icons/double-arrow.png" alt=""/></a>' +
								'<button type="button" class="on-icon-btn" data-accion="editar" aria-label="Editar juego">' +
									'<i class="fa fa-pencil" aria-hidden="true"></i></button>' +
								'<button type="button" class="on-icon-btn on-peligro" data-accion="eliminar" aria-label="Eliminar juego">' +
									'<i class="fa fa-trash" aria-hidden="true"></i></button>' +
							'</div>' +
						'</div>' +
					'</div>' +
				'</div>' +
			'</div>'
		);
	});
}

function initResenas() {
	window.PaginaActual = 'resenas';
	$('#filtro-resenas').on('change', function () {
		estadoResenas.minimo = Number($(this).val());
		renderizarResenas();
	});
	renderizarResenas();
}

/* ============================================================
   8. PÁGINA NOVEDADES (blog.html) - Últimos juegos agregados
   ============================================================ */

function renderizarNovedades() {
	/* Se ordena por fecha de lanzamiento (más recientes primero) */
	const lista = Store.obtenerCatalogo().slice()
		.sort(function (a, b) { return String(b.fecha).localeCompare(String(a.fecha)); })
		.slice(0, 6);

	const $cont = $('#lista-novedades').empty();
	lista.forEach(function (juego, i) {
		$cont.append(
			'<div class="blog-item on-card" data-id="' + escaparHTML(juego.id) + '">' +
				'<div class="blog-thumb">' +
					'<img src="' + escaparHTML(juego.imagen) + '" alt="Portada de ' + escaparHTML(juego.titulo) + '"' +
						' onerror="this.onerror=null;this.src=\'' + IMAGEN_RESPALDO + '\'">' +
				'</div>' +
				'<div class="blog-text text-box text-white">' +
					'<div class="top-meta">' + formatearFecha(juego.fecha) + ' / en ' +
						'<a href="games.html?genero=' + encodeURIComponent(juego.genero) + '">' +
						escaparHTML(juego.genero) + '</a></div>' +
					'<h3>' + escaparHTML(juego.titulo) + '</h3>' +
					'<p>' + escaparHTML(juego.descripcion) + '</p>' +
					'<div class="on-card-actions">' +
						'<a href="game-single.html?id=' + encodeURIComponent(juego.id) +
							'" class="read-more">Ver más <img src="img/icons/double-arrow.png" alt=""/></a>' +
						'<button type="button" class="on-icon-btn" data-accion="editar" aria-label="Editar juego">' +
							'<i class="fa fa-pencil" aria-hidden="true"></i></button>' +
						'<button type="button" class="on-icon-btn on-peligro" data-accion="eliminar" aria-label="Eliminar juego">' +
							'<i class="fa fa-trash" aria-hidden="true"></i></button>' +
					'</div>' +
				'</div>' +
			'</div>'
		);
	});
}

function initNovedades() {
	window.PaginaActual = 'novedades';

	/* Widget de categorías: enlaces al catálogo filtrado por género */
	const $cats = $('#novedades-categorias').empty();
	generosDelCatalogo().forEach(function (genero) {
		$cats.append('<li><a href="games.html?genero=' + encodeURIComponent(genero) + '">' +
			escaparHTML(genero) + '</a></li>');
	});

	/* Buscador del panel lateral: redirige al catálogo con el término (?q=) */
	$('#form-buscador-novedades').on('submit', function (evento) {
		evento.preventDefault();
		const termino = $.trim($('#buscador-novedades').val());
		window.location.href = termino
			? 'games.html?q=' + encodeURIComponent(termino)
			: 'games.html';
	});

	renderizarNovedades();
}

/* ============================================================
   9. PÁGINA INICIO (index.html) - Secciones dinámicas
   ============================================================ */

function initInicio() {
	window.PaginaActual = 'inicio';
	const catalogo = Store.obtenerCatalogo();

	/* --- Destacados: los 3 juegos mejor valorados --- */
	const destacados = catalogo.slice().sort(function (a, b) {
		return b.valoracion - a.valoracion;
	}).slice(0, 3);

	const $dest = $('#inicio-destacados').empty();
	destacados.forEach(function (juego) {
		$dest.append(
			'<div class="col-md-4">' +
				'<div class="intro-text-box text-box text-white on-card" data-id="' + escaparHTML(juego.id) + '">' +
					'<div class="top-meta">' + formatearFecha(juego.fecha) + ' / en ' +
						'<a href="games.html?genero=' + encodeURIComponent(juego.genero) + '">' +
						escaparHTML(juego.genero) + '</a></div>' +
					'<h3>' + escaparHTML(juego.titulo) + '</h3>' +
					'<div class="on-stars">' + generarEstrellas(Number(juego.valoracion)) + '</div>' +
					'<p>' + escaparHTML(juego.descripcion) + '</p>' +
					'<a href="game-single.html?id=' + encodeURIComponent(juego.id) + '" class="read-more">Ver detalle' +
						' <img src="img/icons/double-arrow.png" alt=""/></a>' +
				'</div>' +
			'</div>'
		);
	});

	/* --- Últimas incorporaciones al catálogo (por fecha) --- */
	const ultimos = catalogo.slice().sort(function (a, b) {
		return String(b.fecha).localeCompare(String(a.fecha));
	}).slice(0, 3);

	const $ult = $('#inicio-ultimos').empty();
	ultimos.forEach(function (juego) {
		$ult.append(
			'<div class="blog-item on-card" data-id="' + escaparHTML(juego.id) + '">' +
				'<div class="blog-thumb">' +
					'<img src="' + escaparHTML(juego.imagen) + '" alt="Portada de ' + escaparHTML(juego.titulo) + '"' +
						' onerror="this.onerror=null;this.src=\'' + IMAGEN_RESPALDO + '\'">' +
				'</div>' +
				'<div class="blog-text text-box text-white">' +
					'<div class="top-meta">' + formatearFecha(juego.fecha) + ' / en ' +
						'<a href="games.html?genero=' + encodeURIComponent(juego.genero) + '">' +
						escaparHTML(juego.genero) + '</a></div>' +
					'<h3>' + escaparHTML(juego.titulo) + '</h3>' +
					'<p>' + escaparHTML(juego.descripcion) + '</p>' +
					'<a href="game-single.html?id=' + encodeURIComponent(juego.id) + '" class="read-more">Ver más' +
						' <img src="img/icons/double-arrow.png" alt=""/></a>' +
				'</div>' +
			'</div>'
		);
	});

	/* --- Widget "Tendencias": top 4 por valoración --- */
	const tendencias = catalogo.slice().sort(function (a, b) {
		return b.valoracion - a.valoracion;
	}).slice(0, 4);

	const $tend = $('#inicio-tendencias').empty();
	tendencias.forEach(function (juego) {
		$tend.append(
			'<div class="tw-item">' +
				'<div class="tw-thumb">' +
					'<img src="' + escaparHTML(juego.imagen) + '" alt="Portada de ' + escaparHTML(juego.titulo) + '"' +
						' onerror="this.onerror=null;this.src=\'' + IMAGEN_RESPALDO + '\'">' +
				'</div>' +
				'<div class="tw-text">' +
					'<div class="tw-meta">' + escaparHTML(juego.genero) + '</div>' +
					'<h5><a href="game-single.html?id=' + encodeURIComponent(juego.id) + '">' +
						escaparHTML(juego.titulo) + '</a></h5>' +
				'</div>' +
			'</div>'
		);
	});

	/* --- Widget de categorías: enlaces a filtros del catálogo --- */
	const $cats = $('#inicio-categorias').empty();
	generosDelCatalogo().forEach(function (genero) {
		$cats.append('<li><a href="games.html?genero=' + encodeURIComponent(genero) + '">' +
			escaparHTML(genero) + '</a></li>');
	});

	/* --- Contador de estadísticas del catálogo --- */
	const totalApi = catalogo.filter(function (j) { return j.origen === 'api'; }).length;
	$('#stat-total').text(catalogo.length);
	$('#stat-api').text(totalApi);
	$('#stat-generos').text(generosDelCatalogo().length);
}

/* ============================================================
   10. PÁGINA CONTACTO (contact.html) - Formulario funcional
   ============================================================ */

function initContacto() {
	window.PaginaActual = 'contacto';

	$('#form-contacto').on('submit', function (evento) {
		evento.preventDefault();

		if (!this.checkValidity()) {
			$(this).addClass('was-validated');
			return;
		}

		/* El mensaje se persiste en LocalStorage en formato JSON */
		Store.agregarMensaje({
			nombre: $.trim($('#contacto-nombre').val()),
			email: $.trim($('#contacto-email').val()),
			asunto: $.trim($('#contacto-asunto').val()),
			mensaje: $.trim($('#contacto-mensaje').val()),
			fecha: new Date().toISOString()
		});

		this.reset();
		$(this).removeClass('was-validated');
		$('#contacto-exito').removeClass('d-none');
		mostrarToast('¡Mensaje enviado! Te responderemos pronto.');
		setTimeout(function () { $('#contacto-exito').addClass('d-none'); }, 6000);
	});
}

/* ============================================================
   11. BOLETÍN DE NOTICIAS (presente en todas las páginas)
   ============================================================ */

$(document).on('submit', '.newsletter-form', function (evento) {
	evento.preventDefault();
	const $input = $(this).find('input[type="email"]');
	const email = $.trim($input.val());

	/* Validación simple del correo electrónico */
	if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
		mostrarToast('Ingresa un correo electrónico válido.', 'error');
		return;
	}

	Store.agregarBoletin(email);
	$input.val('');
	mostrarToast('¡Suscripción registrada! Gracias por unirte.');
});

/* ============================================================
   12. ARRANQUE GENERAL
   Se detecta la página actual mediante el atributo data-page
   declarado en la etiqueta <body> de cada documento HTML.
   ============================================================ */

$(function () {
	/* Carga inicial del catálogo (semilla la primera vez) */
	Store.inicializarCatalogo();

	/* Consumo automático de la API externa para enriquecer el
	   catálogo; si falla (sin conexión) se continúa con los datos
	   locales sin interrumpir la experiencia del usuario. */
	API.sincronizar()
		.done(function (nuevos) {
			if (nuevos > 0 && window.PaginaActual === 'inicio') initInicio();
			if (nuevos > 0 && window.PaginaActual === 'catalogo') {
				llenarSelect($('#filtro-genero'), generosDelCatalogo(), estadoCatalogo.genero, 'Todas las categorías');
				llenarSelect($('#filtro-plataforma'), plataformasDelCatalogo(), estadoCatalogo.plataforma, 'Todas las plataformas');
				renderizarCatalogo();
			}
		})
		.fail(function () { /* modo sin conexión: se usan los datos locales */ });

	/* Inicialización según la página abierta */
	switch ($('body').data('page')) {
		case 'inicio': initInicio(); break;
		case 'catalogo': initCatalogo(); break;
		case 'detalle': initDetalle(); break;
		case 'resenas': initResenas(); break;
		case 'novedades': initNovedades(); break;
		case 'contacto': initContacto(); break;
	}
});
