"""Backend local de Omega Nexus: SQLite + API HTTP sin dependencias externas."""

import json
import sqlite3
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent
DATABASE = ROOT / "omega_nexus.db"
BACKUP = ROOT / "js" / "api-respaldo.json"
HOST = "127.0.0.1"
PORT = 8000


def map_backup_game(item):
    """Acepta tanto el formato de la API externa como el esquema
    interno usado por los respaldos exportados desde la base de
    datos (conserva id, valoración y origen sin recalcularlos)."""
    if isinstance(item.get("titulo"), str):
        juego = dict(item)
        juego["id"] = str(item.get("id", ""))
        return juego
    game_id = item.get("id")
    return {
        "id": "api-" + str(game_id),
        "titulo": item.get("title", ""),
        "genero": item.get("genre", ""),
        "plataforma": item.get("platform", ""),
        "fecha": item.get("release_date", ""),
        "valoracion": round(((int(game_id) % 20) / 10 + 3) * 10) / 10,
        "descripcion": item.get("short_description", ""),
        "desarrollador": item.get("developer") or "Desconocido",
        "imagen": item.get("thumbnail", ""),
        "juego_url": item.get("game_url", ""),
        "origen": "api",
    }


def read_backup():
    with BACKUP.open("r", encoding="utf-8") as file:
        return [map_backup_game(item) for item in json.load(file)]


def connection():
    database = sqlite3.connect(DATABASE)
    database.row_factory = sqlite3.Row
    return database


def setup_database():
    database = connection()
    database.execute(
        """CREATE TABLE IF NOT EXISTS juegos (
            id TEXT PRIMARY KEY,
            titulo TEXT NOT NULL,
            genero TEXT NOT NULL,
            plataforma TEXT NOT NULL,
            fecha TEXT,
            valoracion REAL NOT NULL DEFAULT 0,
            descripcion TEXT,
            desarrollador TEXT,
            imagen TEXT,
            juego_url TEXT,
            origen TEXT NOT NULL DEFAULT 'local',
            actualizado_en TEXT NOT NULL
        )"""
    )
    database.commit()
    if database.execute("SELECT COUNT(*) FROM juegos").fetchone()[0] == 0:
        save_games(database, read_backup())
    database.close()


def save_games(database, games):
    timestamp = datetime.now(timezone.utc).isoformat()
    database.execute("DELETE FROM juegos")
    normalized_games = []
    for game in games:
        normalized_games.append({
            "id": str(game.get("id", "")),
            "titulo": game.get("titulo", ""),
            "genero": game.get("genero", ""),
            "plataforma": game.get("plataforma", ""),
            "fecha": game.get("fecha", ""),
            "valoracion": game.get("valoracion", 0),
            "descripcion": game.get("descripcion", ""),
            "desarrollador": game.get("desarrollador", ""),
            "imagen": game.get("imagen", ""),
            "juego_url": game.get("juego_url", ""),
            "origen": game.get("origen", "local"),
            "actualizado_en": timestamp,
        })
    database.executemany(
        """INSERT INTO juegos
        (id, titulo, genero, plataforma, fecha, valoracion, descripcion,
         desarrollador, imagen, juego_url, origen, actualizado_en)
        VALUES (:id, :titulo, :genero, :plataforma, :fecha, :valoracion,
                :descripcion, :desarrollador, :imagen, :juego_url, :origen,
                :actualizado_en)""",
        normalized_games,
    )
    database.commit()


def all_games(database):
    rows = database.execute(
        "SELECT id, titulo, genero, plataforma, fecha, valoracion, descripcion, "
        "desarrollador, imagen, juego_url, origen FROM juegos ORDER BY titulo"
    ).fetchall()
    return [dict(row) for row in rows]


def export_backup():
    """Reemplaza el JSON de respaldo con el contenido actual de la base de datos."""
    database = connection()
    juegos = all_games(database)
    database.close()
    BACKUP.write_text(
        json.dumps(juegos, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return len(juegos)


class RequestHandler(BaseHTTPRequestHandler):
    def send_json(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def read_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        return json.loads(self.rfile.read(length).decode("utf-8"))

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, PUT, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/catalogo":
            database = connection()
            games = all_games(database)
            database.close()
            self.send_json(200, games)
            return
        if path == "/api/estado":
            database = connection()
            count = database.execute("SELECT COUNT(*) FROM juegos").fetchone()[0]
            database.close()
            self.send_json(200, {"base_datos": str(DATABASE.name), "juegos": count})
            return
        self.serve_static(path)

    def do_PUT(self):
        if urlparse(self.path).path != "/api/catalogo":
            self.send_json(404, {"error": "Ruta no encontrada"})
            return
        games = self.read_json()
        if not isinstance(games, list):
            self.send_json(400, {"error": "El catálogo debe ser un arreglo JSON"})
            return
        database = connection()
        save_games(database, games)
        database.close()
        self.send_json(200, {"guardados": len(games)})

    def do_POST(self):
        if urlparse(self.path).path == "/api/exportar-respaldo":
            self.send_json(200, {"exportados": export_backup()})
            return
        if urlparse(self.path).path != "/api/restaurar-respaldo":
            self.send_json(404, {"error": "Ruta no encontrada"})
            return
        database = connection()
        games = read_backup()
        save_games(database, games)
        database.close()
        self.send_json(200, {"restaurados": len(games), "catalogo": games})

    def serve_static(self, path):
        relative = "games.html" if path in ("", "/") else path.lstrip("/")
        file_path = (ROOT / relative).resolve()
        if ROOT not in file_path.parents and file_path != ROOT:
            self.send_error(403)
            return
        if not file_path.is_file():
            self.send_error(404)
            return
        content_type = "text/html; charset=utf-8"
        if file_path.suffix == ".js":
            content_type = "text/javascript; charset=utf-8"
        elif file_path.suffix == ".css":
            content_type = "text/css; charset=utf-8"
        elif file_path.suffix == ".json":
            content_type = "application/json; charset=utf-8"
        data = file_path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, format_string, *args):
        print("%s - %s" % (self.address_string(), format_string % args))


if __name__ == "__main__":
    setup_database()
    print("Omega Nexus disponible en http://%s:%s" % (HOST, PORT))
    ThreadingHTTPServer((HOST, PORT), RequestHandler).serve_forever()
