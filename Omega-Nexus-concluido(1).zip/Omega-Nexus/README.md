# Omega Nexus — Plataforma Web Interactiva de Catálogo Digital Temático

**Proyecto Integrador | Diseño Web II | Gestión 2026 — Segundo Semestre**
Alineado al Objetivo de Desarrollo Sostenible **ODS 9: Industria, Innovación e Infraestructura**

Omega Nexus es una plataforma web interactiva para la **gestión y consulta de un catálogo digital temático de videojuegos**. Permite buscar, filtrar, ordenar, registrar, modificar, eliminar y valorar juegos, enriqueciendo el catálogo con datos reales consumidos desde una API pública externa. Con `server.py`, los datos se persisten en SQLite y LocalStorage funciona como caché offline.

---

## 1. Tecnologías aplicadas

| Tecnología | Uso en el proyecto |
|---|---|
| HTML5 | Maquetación semántica de las 6 páginas de la plataforma |
| CSS3 | Estilos propios (`css/custom.css`) sobre la plantilla base |
| Bootstrap 4.2 | Framework CSS: grilla responsive, modal CRUD, formularios |
| JavaScript (ES6+) | Manipulación del DOM, eventos, lógica de negocio |
| jQuery 3.2 | Selección/manipulación del DOM y peticiones AJAX |
| AJAX + JSON | Consumo de la API pública FreeToGame (`$.ajax`, `dataType: json`) |
| SQLite + Python | Base de datos persistente del catálogo y API local CRUD |
| LocalStorage | Caché offline del catálogo, favoritos, mensajes y suscripciones |

## 2. Estructura del proyecto

```
Omega-Nexus/
├── index.html          → Inicio: destacados, últimas incorporaciones, estadísticas
├── games.html          → Catálogo: búsqueda, filtros, ordenamiento y CRUD
├── game-single.html    → Vista de detalle dinámica (?id=identificador)
├── review.html         → Reseñas ordenadas por valoración con filtro mínimo
├── blog.html           → Novedades: últimos juegos agregados + buscador lateral
├── contact.html        → Contacto: formulario funcional validado
├── css/
│   ├── style.css       → Estilos base de la plantilla
│   └── custom.css      → Estilos propios de la plataforma
├── js/
│   ├── data.js         → Catálogo semilla en formato JSON (respaldo sin conexión)
│   ├── app.js          → Lógica principal: Store, API, render, CRUD, filtros y paginación
│   ├── api-respaldo.json → Instantánea completa de la API FreeToGame (415 juegos) usada como copia de seguridad si la API externa falla
│   └── main.js         → Comportamientos de la plantilla (slider, menú, etc.)
└── img/                → Recursos gráficos
```

## 3. Cumplimiento de los requerimientos (Perfil del Proyecto)

### Requerimientos funcionales

| Requerimiento | Implementación |
|---|---|
| Búsqueda de elementos | Buscador en vivo por nombre/palabra clave en `games.html` (título, descripción y desarrollador) y buscador lateral en `blog.html` |
| Filtros por categoría u otro criterio | Filtros por género y plataforma alimentados dinámicamente desde el catálogo |
| Organización por categorías | Widgets de categorías en Inicio/Novedades que enlazan al catálogo filtrado (`?genero=`) |
| Paginación de resultados | El catálogo muestra 12 juegos por página con navegación numerada (primera, última, elipsis y anterior/siguiente); búsqueda, filtros y orden reinician a la página 1 |
| Vista de detalle | `game-single.html?id=` con ficha técnica, valoración, relacionados y acciones CRUD |
| Navegación clara entre secciones | Menú principal y pie de página consistentes en las 6 páginas + breadcrumbs |
| Consumo de al menos una API externa | API pública [FreeToGame](https://www.freetogame.com/api) vía AJAX; botón "Sincronizar API" y sincronización automática al iniciar. Si la API no responde, se usa automáticamente la copia local de respaldo `js/api-respaldo.json` (mismo formato JSON que devuelve la API) |
| Persistencia con LocalStorage | Claves: `on_catalogo`, `on_favoritos`, `on_mensajes`, `on_boletin` |
| Manejo de datos JSON | Catálogo semilla (`data.js`), respuestas de la API y almacenamiento local en JSON |
| Diseño responsive | Grilla Bootstrap 4 + media queries de la plantilla (móvil, tablet, escritorio) |
| Framework CSS | Bootstrap 4.2 incluido y utilizado (grilla, modal, formularios, utilidades) |

**CRUD completo:** registro (modal "Agregar juego"), modificación (botón editar), eliminación (con confirmación) y búsqueda de contenidos del catálogo.

### Requerimientos no funcionales

- Interfaz coherente con identidad propia (paleta y componentes Omega Nexus).
- Usabilidad: navegación intuitiva, estados vacíos y notificaciones (toasts).
- Accesibilidad básica: atributos `alt` descriptivos, etiquetas `label`/`aria-label`, foco visible, contraste adecuado.
- Rendimiento: renderizado dinámico sin recargas, imágenes con respaldo automático.
- Código organizado y comentado en módulos (Store / API / Render / CRUD).
- Repositorio Git con historial de commits que evidencia el desarrollo.

## 4. Limitaciones respetadas

Sin autenticación real, sin pasarelas de pagos, sin apps nativas y sin panel administrativo complejo, conforme a la sección 7 del perfil del proyecto.

## 5. Puesta en marcha

1. Descargar o clonar el repositorio.
2. Tener Python 3 instalado y ejecutar `python server.py` desde la carpeta del proyecto.
3. Abrir `http://127.0.0.1:8000` en un navegador moderno.
4. La primera ejecución crea `omega_nexus.db` e importa todos los juegos de `js/api-respaldo.json`.

El botón **Restaurar respaldo** reemplaza el catálogo de SQLite con todos los registros del JSON, y el botón **Exportar respaldo** hace lo contrario: guarda el contenido actual de la base de datos dentro de `js/api-respaldo.json`, de modo que la copia sin conexión siempre refleje los datos más recientes (el respaldo admite tanto el formato de la API externa como el esquema interno del catálogo). Cada alta, modificación, eliminación y sincronización del catálogo se guarda mediante la API local. Si se abre `index.html` directamente, la aplicación continúa funcionando con LocalStorage, pero no puede escribir en SQLite.

> Nota: para trabajar sin backend se puede abrir el HTML directamente; en ese caso los cambios quedan únicamente en el navegador actual.

## 6. Manual de usuario

### Explorar el catálogo
- Ingresa a **Catálogo** para ver todos los juegos.
- Usa el **buscador** para encontrar juegos por nombre o palabra clave; los resultados se actualizan mientras escribes.
- Filtra por **categoría** o **plataforma** con los menús desplegables.
- Ordena por nombre (A-Z / Z-A), valoración (mayor/menor) o fecha (recientes/antiguos).
- Avanza entre páginas con la **paginación** inferior (12 juegos por página).

### Respaldo de datos
- **Exportar respaldo**: reemplaza `js/api-respaldo.json` con los juegos actuales de la base de datos SQLite, para que la copia sin conexión incluya tus registros nuevos y modificaciones.
- **Restaurar respaldo**: reemplaza el catálogo de SQLite con todo el contenido del JSON.

### Registrar un juego nuevo
1. En el catálogo pulsa **Agregar juego**.
2. Completa el formulario (título, categoría y plataforma son obligatorios).
3. Pulsa **Guardar juego**: aparecerá en la grilla y quedará guardado en tu navegador.

### Modificar o eliminar un juego
- En cada tarjeta usa el ícono de **lápiz** para modificar sus datos o el de **basurero** para eliminarlo (pedirá confirmación).
- También puedes hacerlo desde la ficha de detalle del juego.

### Favoritos
- Marca juegos con el ícono de **corazón**; quedan guardados en tu navegador incluso si cierras la página.

### Reseñas y novedades
- En **Reseñas** verás los juegos ordenados por valoración; puedes filtrar por puntaje mínimo.
- En **Novedades** aparecen los últimos juegos incorporados al catálogo.

### Contacto y boletín
- En **Contacto**, completa el formulario y envía: tu mensaje queda registrado y verás una confirmación.
- Suscríbete al boletín ingresando tu correo en la parte inferior de cualquier página.

---

*Facultad de Ingeniería — Ingeniería de Sistemas | Asignatura: Diseño Web II | Docente: Lic. Toro Carlos | Cochabamba, Bolivia*
