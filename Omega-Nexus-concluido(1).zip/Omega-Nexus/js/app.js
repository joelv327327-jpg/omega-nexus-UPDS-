/* ============================================================
   OMEGA NEXUS - Catálogo Digital Temático de Videojuegos
   Proyecto Integrador - Diseño Web II (ODS 9)
   ------------------------------------------------------------
   app.js
   Lógica principal de la plataforma:
     - Store  : persistencia de datos en LocalStorage + SQLite
     - Render : generación dinámica del DOM
     - CRUD   : registro, modificación y eliminación de juegos
     - Búsqueda, filtros por categoría y ordenamiento
   ============================================================ */

'use strict';

/* ============================================================
	1. MÓDULO STORE - Persistencia local y base de datos SQLite
   ============================================================ */
const Store = {
	CLAVE_CATALOGO: 'on_catalogo',
	CLAVE_FAVORITOS: 'on_favoritos',
	CLAVE_MENSAJES: 'on_mensajes',
	CLAVE_BOLETIN: 'on_boletin',

	obtenerCatalogo: function () {
		try {
			return JSON.parse(localStorage.getItem(this.CLAVE_CATALOGO)) || [];
		} catch (e) {
			return [];
		}
	},

	guardarCatalogoLocal: function (lista) {
		localStorage.setItem(this.CLAVE_CATALOGO, JSON.stringify(lista));
	},

	cargarDesdeBaseDatos: function () {
		return $.ajax({ url: 'api/catalogo', dataType: 'json', method: 'GET' })
			.then(function (lista) {
				if (Array.isArray(lista)) {
					localStorage.setItem(Store.CLAVE_CATALOGO, JSON.stringify(lista));
				}
				return lista;
			});
	},

	restaurarRespaldo: function () {
		return $.ajax({ url: 'api/restaurar-respaldo', dataType: 'json', method: 'POST' })
			.then(function (respuesta) {
				localStorage.setItem(Store.CLAVE_CATALOGO, JSON.stringify(respuesta.catalogo));
				return respuesta;
			});
	},

	exportarRespaldo: function () {
		return $.ajax({ url: 'api/exportar-respaldo', dataType: 'json', method: 'POST' });
	},

	inicializarCatalogo: function () {
		if (!localStorage.getItem(this.CLAVE_CATALOGO)) {
			localStorage.setItem(this.CLAVE_CATALOGO, JSON.stringify(SEED_CATALOGO));
		}
	},

	buscarPorId: function (id) {
		return this.obtenerCatalogo().find(function (j) {
			return String(j.id) === String(id);
		});
	},

	agregar: function (juego) {
		juego.origen = 'local';
		juego.api_id = '';
		juego.juego_url = '';
		return $.ajax({
			url: 'api/juego',
			method: 'POST',
			dataType: 'json',
			contentType: 'application/json',
			data: JSON.stringify(juego)
		}).then(function (respuesta) {
			juego.id = respuesta.id;
			const lista = Store.obtenerCatalogo();
			lista.push(juego);
			Store.guardarCatalogoLocal(lista);
			return juego;
		});
	},

	actualizar: function (juego) {
		return $.ajax({
			url: 'api/juego/' + juego.id,
			method: 'PUT',
			dataType: 'json',
			contentType: 'application/json',
			data: JSON.stringify(juego)
		}).then(function () {
			const lista = Store.obtenerCatalogo();
			const indice = lista.findIndex(function (j) {
				return String(j.id) === String(juego.id);
			});
			if (indice !== -1) {
				juego.origen = lista[indice].origen;
				lista[indice] = juego;
				Store.guardarCatalogoLocal(lista);
			}
			return juego;
		});
	},

	eliminar: function (id) {
		return $.ajax({
			url: 'api/juego/' + id,
			method: 'DELETE',
			dataType: 'json'
		}).then(function () {
			const lista = Store.obtenerCatalogo().filter(function (j) {
				return String(j.id) !== String(id);
			});
			Store.guardarCatalogoLocal(lista);
		});
	},

	/* ---------- Favoritos ---------- */

	obtenerFavoritos: function () {
		try {
			return JSON.parse(localStorage.getItem(this.CLAVE_FAVORITOS)) || [];
		} catch (e) {
			return [];
		}
	},

	esFavorito: function (id) {
		return this.obtenerFavoritos().some(function (f) {
			return String(f) === String(id);
		});
	},

	alternarFavorito: function (id) {
		let favs = this.obtenerFavoritos();
		if (this.esFavorito(id)) {
			favs = favs.filter(function (f) { return String(f) !== String(id); });
		} else {
			favs.push(String(id));
		}
		localStorage.setItem(this.CLAVE_FAVORITOS, JSON.stringify(favs));
		return this.esFavorito(id);
	},

	/* ---------- Mensajes y boletín ---------- */

	agregarMensaje: function (mensaje) {
		const mensajes = JSON.parse(localStorage.getItem(this.CLAVE_MENSAJES) || '[]');
		mensajes.push(mensaje);
		localStorage.setItem(this.CLAVE_MENSAJES, JSON.stringify(mensajes));
	},

	agregarBoletin: function (email) {
		const correos = JSON.parse(localStorage.getItem(this.CLAVE_BOLETIN) || '[]');
		if (!correos.includes(email)) correos.push(email);
		localStorage.setItem(this.CLAVE_BOLETIN, JSON.stringify(correos));
	}
};

/* ============================================================
   2. UTILIDADES GENERALES
   ============================================================ */

function escaparHTML(texto) {
	return String(texto == null ? '' : texto)
		.replace(/&/g, '&amp;').replace(/</g, '&lt;')
		.replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function formatearFecha(iso) {
	if (!iso) return 'Sin fecha';
	const partes = String(iso).split('-');
	if (partes.length !== 3) return iso;
	return partes[2] + '/' + partes[1] + '/' + partes[0];
}

function listaDe(juego, campoNuevo, campoViejo) {
	if (Array.isArray(juego[campoNuevo])) {
		return juego[campoNuevo].filter(function (v) { return v; });
	}
	if (juego[campoViejo]) {
		return String(juego[campoViejo]).split(',').map(function (s) { return s.trim(); })
			.filter(function (s) { return s; });
	}
	return [];
}

function generosDe(juego) { return listaDe(juego, 'generos', 'genero'); }
function plataformasDe(juego) { return listaDe(juego, 'plataformas', 'plataforma'); }
function primerGenero(juego) { return generosDe(juego)[0] || 'Sin categoría'; }
function textoGeneros(juego) { return generosDe(juego).join(', '); }
function textoPlataformas(juego) { return plataformasDe(juego).join(', '); }

function generarEstrellas(valoracion) {
	let html = '';
	for (let i = 1; i <= 5; i++) {
		if (valoracion >= i) {
			html += '<i class="fa fa-star" aria-hidden="true"></i>';
		} else if (valoracion >= i - 0.5) {
			html += '<i class="fa fa-star-half-o" aria-hidden="true"></i>';
		} else {
			html += '<i class="fa fa-star-o" aria-hidden="true"></i>';
		}
	}
	return html;
}

function parametroURL(nombre) {
	return new URLSearchParams(window.location.search).get(nombre);
}

function mostrarToast(mensaje, tipo) {
	const $toast = $(
		'<div class="on-toast ' + (tipo || 'exito') + '" role="status" aria-live="polite">' +
		escaparHTML(mensaje) + '</div>'
	);
	$('body').append($toast);
	setTimeout(function () { $toast.addClass('visible'); }, 10);
	setTimeout(function () {
		$toast.removeClass('visible');
		setTimeout(function () { $toast.remove(); }, 400);
	}, 2600);
}

const IMAGEN_RESPALDO = 'img/games/big.jpg';

function tarjetaJuego(juego) {
	const esFav = Store.esFavorito(juego.id);
	return '' +
	'<div class="col-lg-4 col-md-6">' +
		'<div class="game-item on-card" data-id="' + escaparHTML(juego.id) + '">' +
			'<a href="game-single.html?id=' + encodeURIComponent(juego.id) + '" class="on-card-img-link">' +
				'<img src="' + escaparHTML(juego.imagen) + '" alt="Portada del juego ' + escaparHTML(juego.titulo) + '"' +
					' onerror="this.onerror=null;this.src=\'' + IMAGEN_RESPALDO + '\'">' +
			'</a>' +
			'<span class="on-badge">' + escaparHTML(primerGenero(juego)) + '</span>' +
			'<h5><a href="game-single.html?id=' + encodeURIComponent(juego.id) + '">' + escaparHTML(juego.titulo) + '</a></h5>' +
			'<div class="on-card-meta">' +
				'<span class="on-stars" aria-label="Valoración ' + juego.valoracion + ' de 5">' +
					generarEstrellas(Number(juego.valoracion) || 0) +
					' <b>' + Number(juego.valoracion).toFixed(1) + '</b></span>' +
			'</div>' +
			'<div class="on-developer"><i class="fa fa-gamepad" aria-hidden="true"></i> ' +
				escaparHTML(juego.desarrollador || 'Independiente') + '</div>' +
			'<p class="on-desc">' + escaparHTML(juego.descripcion).substring(0, 40) + (juego.descripcion.length > 40 ? '... ' : '') + '</p>' +
			'<div class="on-card-actions">' +
				'<a href="game-single.html?id=' + encodeURIComponent(juego.id) + '" class="read-more">Ver detalle' +
					' <img src="img/icons/double-arrow.png" alt=""/></a>' +
				'<button type="button" class="on-icon-btn on-fav' + (esFav ? ' activo' : '') + '"' +
					' data-accion="favorito" aria-label="Marcar como favorito"' +
					' title="Favorito"><i class="fa fa-heart" aria-hidden="true"></i></button>' +
				'<button type="button" class="on-icon-btn" data-accion="editar"' +
					' aria-label="Editar juego" title="Editar"><i class="fa fa-pencil" aria-hidden="true"></i></button>' +
				'<button type="button" class="on-icon-btn on-peligro" data-accion="eliminar"' +
					' aria-label="Eliminar juego" title="Eliminar"><i class="fa fa-trash" aria-hidden="true"></i></button>' +
			'</div>' +
		'</div>' +
	'</div>';
}

function llenarSelect($select, valores, valorActual, textoVacio) {
	$select.find('option').remove();
	if (textoVacio) {
		$select.append('<option value="">' + escaparHTML(textoVacio) + '</option>');
	}
	valores.forEach(function (v) {
		$select.append('<option value="' + escaparHTML(v) + '">' + escaparHTML(v) + '</option>');
	});
	if (valorActual) $select.val(valorActual);
}

function generosDelCatalogo() {
	const set = new Set(GENEROS_BASE);
	Store.obtenerCatalogo().forEach(function (j) {
		generosDe(j).forEach(function (g) { set.add(g); });
	});
	return Array.from(set).sort();
}

function plataformasDelCatalogo() {
	const set = new Set(PLATAFORMAS_BASE);
	Store.obtenerCatalogo().forEach(function (j) {
		plataformasDe(j).forEach(function (p) { set.add(p); });
	});
	return Array.from(set).sort();
}

/* Opciones de filtro del catálogo: solo categorías/plataformas que realmente
   tienen al menos un juego, sin las listas base (que pueden quedar vacías). */
function generosConJuegos() {
	const set = new Set();
	Store.obtenerCatalogo().forEach(function (j) {
		generosDe(j).forEach(function (g) { set.add(g); });
	});
	return Array.from(set).sort();
}

function plataformasConJuegos() {
	const set = new Set();
	Store.obtenerCatalogo().forEach(function (j) {
		plataformasDe(j).forEach(function (p) { set.add(p); });
	});
	return Array.from(set).sort();
}

/* ============================================================
   3. FORMULARIO DE ALTA / EDICIÓN (CRUD) - Modal Bootstrap
   ============================================================ */

function llenarSelectMultiple($select, valores, seleccionados) {
	$select.find('option').remove();
	valores.forEach(function (v) {
		$select.append('<option value="' + escaparHTML(v) + '">' + escaparHTML(v) + '</option>');
	});
	seleccionados = (seleccionados || []).filter(function (v) {
		return valores.indexOf(v) !== -1;
	});
	if (seleccionados.length) $select.val(seleccionados);
}

function llenarCboxMultiple($menu, $label, valores, seleccionados) {
	$menu.empty();
	seleccionados = seleccionados || [];
	valores.forEach(function (v) {
		const marcada = seleccionados.indexOf(v) !== -1;
		$menu.append(
			'<label class="on-cbox-item">' +
				'<input type="checkbox" value="' + escaparHTML(v) + '"' + (marcada ? ' checked' : '') + '> ' +
				escaparHTML(v) +
			'</label>'
		);
	});
	actualizarCboxLabel($menu, $label);
}

function actualizarCboxLabel($menu, $label) {
	const seleccionadas = cboxSeleccionadas($menu);
	$label.text(seleccionadas.length ? seleccionadas.join(', ') : 'Seleccionar');
}

function cboxSeleccionadas($menu) {
	return $menu.find('input[type=checkbox]:checked').map(function () {
		return this.value;
	}).get();
}

function alternarCbox($root) {
	const abierto = $root.hasClass('abierto');
	$('.on-cbox.abierto').removeClass('abierto');
	if (!abierto) $root.addClass('abierto');
}

$(document).ready(function () {
	$(document).on('click', '.on-cbox-toggle', function (e) {
		e.stopPropagation();
		alternarCbox($(this).closest('.on-cbox'));
	});
	$(document).on('click', '.on-cbox-item input', function (e) {
		e.stopPropagation();
		actualizarCboxLabel(
			$(this).closest('.on-cbox-menu'),
			$(this).closest('.on-cbox').find('.on-cbox-toggle span').first()
		);
	});
	$(document).on('click', function (e) {
		if (!$(e.target).closest('.on-cbox').length) {
			$('.on-cbox.abierto').removeClass('abierto');
		}
	});
});

function abrirModalJuego(juego) {
	const $form = $('#form-juego');
	$form.removeClass('was-validated')[0].reset();
	$('#juego-id').val(juego ? juego.id : '');
	llenarCboxMultiple($('#juego-genero-menu'), $('#juego-genero-label'), generosDelCatalogo(), juego ? generosDe(juego) : []);
	llenarCboxMultiple($('#juego-plataforma-menu'), $('#juego-plataforma-label'), plataformasDelCatalogo(), juego ? plataformasDe(juego) : []);
	if (juego) {
		$('#modal-juego-titulo').text('Modificar juego');
		$('#juego-titulo').val(juego.titulo);
		$('#juego-fecha').val(juego.fecha);
		$('#juego-valoracion').val(juego.valoracion);
		$('#juego-desarrollador').val(juego.desarrollador);
		$('#juego-imagen').val(juego.imagen);
		$('#juego-descripcion').val(juego.descripcion);
	} else {
		$('#modal-juego-titulo').text('Registrar nuevo juego');
	}
	$('#modal-juego').modal('show');
}

function guardarFormularioJuego(evento) {
	evento.preventDefault();
	const $form = $('#form-juego');

	const id = $('#juego-id').val();
	const generos = cboxSeleccionadas($('#juego-genero-menu'));
	const plataformas = cboxSeleccionadas($('#juego-plataforma-menu'));

	if (!$form[0].checkValidity() || !generos || !generos.length || !plataformas || !plataformas.length) {
		$form.addClass('was-validated');
		if (!generos || !generos.length) mostrarToast('Selecciona al menos una categoría.', 'error');
		if (!plataformas || !plataformas.length) mostrarToast('Selecciona al menos una plataforma.', 'error');
		if (generos && generos.length && plataformas && plataformas.length && !$form[0].checkValidity()) {
			mostrarToast('Revisa los campos del formulario.', 'error');
		}
		return;
	}

	const datos = {
		titulo: $.trim($('#juego-titulo').val()),
		generos: generos,
		plataformas: plataformas,
		fecha: $('#juego-fecha').val(),
		valoracion: Number($('#juego-valoracion').val()),
		descripcion: $.trim($('#juego-descripcion').val()),
		desarrollador: $.trim($('#juego-desarrollador').val()) || 'Independiente',
		imagen: $.trim($('#juego-imagen').val()) || IMAGEN_RESPALDO
	};

	$('#modal-juego').modal('hide');

	if (id) {
		const original = Store.buscarPorId(id);
		datos.id = Number(id);
		datos.juego_url = original ? (original.juego_url || '') : '';
		datos.api_id = original ? (original.api_id || '') : '';
		datos.origen = original ? (original.origen || 'local') : 'local';
		Store.actualizar(datos).then(function () {
			mostrarToast('Juego modificado correctamente.');
			refrescarPaginaActual();
		}).fail(function () {
			mostrarToast('Error al modificar el juego.', 'error');
		});
	} else {
		Store.agregar(datos).then(function () {
			mostrarToast('Juego registrado correctamente.');
			refrescarPaginaActual();
		}).fail(function () {
			mostrarToast('Error al registrar el juego.', 'error');
		});
	}
}

function refrescarPaginaActual() {
	if (window.PaginaActual === 'catalogo') {
		llenarSelect($('#filtro-genero'), generosConJuegos(), estadoCatalogo.genero, 'Todas las categorías');
		llenarSelect($('#filtro-plataforma'), plataformasConJuegos(), estadoCatalogo.plataforma, 'Todas las plataformas');
		renderizarCatalogo();
	}
	if (window.PaginaActual === 'detalle') renderizarDetalle();
	if (window.PaginaActual === 'resenas') renderizarResenas();
	if (window.PaginaActual === 'novedades') renderizarNovedades();
	if (window.PaginaActual === 'inicio') initInicio();
}

function eliminarJuego(id) {
	const juego = Store.buscarPorId(id);
	if (!juego) return;
	if (!confirm('¿Estás seguro de eliminar "' + juego.titulo + '" del catálogo?')) return;
	Store.eliminar(id).then(function () {
		mostrarToast('Juego eliminado del catálogo.');
		if (window.PaginaActual === 'catalogo') {
			llenarSelect($('#filtro-genero'), generosConJuegos(), estadoCatalogo.genero, 'Todas las categorías');
			llenarSelect($('#filtro-plataforma'), plataformasConJuegos(), estadoCatalogo.plataforma, 'Todas las plataformas');
			renderizarCatalogo();
		}
		if (window.PaginaActual === 'detalle') window.location.href = 'games.html';
		if (window.PaginaActual === 'resenas') renderizarResenas();
		if (window.PaginaActual === 'novedades') renderizarNovedades();
		if (window.PaginaActual === 'inicio') initInicio();
	}).fail(function () {
		mostrarToast('Error al eliminar el juego.', 'error');
	});
}

$(document).on('click', '.on-card [data-accion]', function () {
	const accion = $(this).data('accion');
	const id = $(this).closest('.on-card').data('id');
	if (accion === 'favorito') {
		const activo = Store.alternarFavorito(id);
		$(this).toggleClass('activo', activo);
		mostrarToast(activo ? 'Agregado a favoritos.' : 'Quitado de favoritos.');
	}
	if (accion === 'editar') abrirModalJuego(Store.buscarPorId(id));
	if (accion === 'eliminar') eliminarJuego(id);
});

/* ============================================================
   4. PÁGINA CATÁLOGO (games.html)
   ============================================================ */

const estadoCatalogo = {
	busqueda: '',
	genero: '',
	plataforma: '',
	favoritos: false,
	pagina: 1,
	porPagina: 12
};

function filtrarCatalogo() {
	let lista = Store.obtenerCatalogo();

	if (estadoCatalogo.favoritos) {
		lista = lista.filter(function (j) { return Store.esFavorito(j.id); });
	}

	if (estadoCatalogo.busqueda) {
		const termino = estadoCatalogo.busqueda.toLowerCase();
		lista = lista.filter(function (j) {
			return j.titulo.toLowerCase().includes(termino);
		});
	} else {
		if (estadoCatalogo.genero) {
			lista = lista.filter(function (j) {
				return generosDe(j).indexOf(estadoCatalogo.genero) !== -1;
			});
		}
		if (estadoCatalogo.plataforma) {
			lista = lista.filter(function (j) {
				return plataformasDe(j).indexOf(estadoCatalogo.plataforma) !== -1;
			});
		}
	}

	lista = lista.slice().sort(function (a, b) { return b.valoracion - a.valoracion; });

	return lista;
}

function renderizarPaginacion(totalPaginas) {
	const $pag = $('#paginacion-catalogo');
	$pag.closest('nav').toggleClass('d-none', totalPaginas <= 1);
	$pag.empty();
	if (totalPaginas <= 1) return;

	const actual = estadoCatalogo.pagina;
	const boton = function (contenido, pagina, activa, deshabilitada) {
		return '<li class="page-item' + (activa ? ' active' : '') +
			(deshabilitada ? ' disabled' : '') + '">' +
			'<button type="button" class="page-link"' +
			(activa ? ' aria-current="page"' : '') +
			' data-pagina="' + pagina + '">' + contenido + '</button></li>';
	};

	let html = boton('<i class="fa fa-angle-left" aria-hidden="true"></i>',
		actual - 1, false, actual === 1);

	const numeros = [1, totalPaginas];
	for (let p = actual - 2; p <= actual + 2; p++) {
		if (p >= 1 && p <= totalPaginas && numeros.indexOf(p) === -1) numeros.push(p);
	}
	numeros.sort(function (a, b) { return a - b; });

	let anterior = 0;
	numeros.forEach(function (p) {
		if (anterior && p - anterior > 1) {
			html += '<li class="page-item disabled"><span class="page-link">&hellip;</span></li>';
		}
		html += boton(String(p), p, p === actual, false);
		anterior = p;
	});

	html += boton('<i class="fa fa-angle-right" aria-hidden="true"></i>',
		actual + 1, false, actual === totalPaginas);

	$pag.html(html);
}

function renderizarCatalogo() {
	const resultados = filtrarCatalogo();
	const $grilla = $('#grilla-catalogo');
	const $vacio = $('#catalogo-vacio');

	const totalPaginas = Math.max(1, Math.ceil(resultados.length / estadoCatalogo.porPagina));
	if (estadoCatalogo.pagina > totalPaginas) estadoCatalogo.pagina = totalPaginas;
	const inicio = (estadoCatalogo.pagina - 1) * estadoCatalogo.porPagina;
	const visibles = resultados.slice(inicio, inicio + estadoCatalogo.porPagina);

	$grilla.empty();
	visibles.forEach(function (juego) {
		$grilla.append(tarjetaJuego(juego));
	});

	const infoPagina = totalPaginas > 1
		? ' · página ' + estadoCatalogo.pagina + ' de ' + totalPaginas
		: '';
	$('#contador-resultados').text(
		resultados.length +
		(resultados.length === 1 ? ' juego encontrado' : ' juegos encontrados') +
		infoPagina
	);
	renderizarPaginacion(totalPaginas);
	$vacio.toggleClass('d-none', resultados.length > 0);
}

function initCatalogo() {
	window.PaginaActual = 'catalogo';

	const q = parametroURL('q');
	const generoURL = parametroURL('genero');
	const favURL = parametroURL('favoritos');
	if (q) { estadoCatalogo.busqueda = q; $('#buscador-catalogo').val(q); }
	if (generoURL) { estadoCatalogo.genero = generoURL; }
	if (favURL) { estadoCatalogo.favoritos = true; }

	const sincronizarFavoritos = function () {
		$('#filtro-favoritos').toggleClass('activo', estadoCatalogo.favoritos)
			.attr('aria-pressed', estadoCatalogo.favoritos);
	};

	llenarSelect($('#filtro-genero'), generosConJuegos(), estadoCatalogo.genero, 'Todas las categorías');
	llenarSelect($('#filtro-plataforma'), plataformasConJuegos(), '', 'Todas las plataformas');

	const sincronizarControles = function () {
		const buscando = !!estadoCatalogo.busqueda;
		const filtrando = !!estadoCatalogo.genero || !!estadoCatalogo.plataforma;
		$('#buscador-catalogo').prop('disabled', filtrando);
		$('#filtro-genero').prop('disabled', buscando);
		$('#filtro-plataforma').prop('disabled', buscando);
	};

	$('#buscador-catalogo').on('input', function () {
		estadoCatalogo.busqueda = $(this).val();
		if (estadoCatalogo.busqueda && (estadoCatalogo.genero || estadoCatalogo.plataforma)) {
			estadoCatalogo.genero = '';
			estadoCatalogo.plataforma = '';
			llenarSelect($('#filtro-genero'), generosConJuegos(), '', 'Todas las categorías');
			llenarSelect($('#filtro-plataforma'), plataformasConJuegos(), '', 'Todas las plataformas');
		}
		estadoCatalogo.pagina = 1;
		sincronizarControles();
		renderizarCatalogo();
	});
	$('#filtro-genero').on('change', function () {
		estadoCatalogo.genero = $(this).val();
		if (estadoCatalogo.genero && estadoCatalogo.busqueda) {
			estadoCatalogo.busqueda = '';
			$('#buscador-catalogo').val('');
		}
		estadoCatalogo.pagina = 1;
		sincronizarControles();
		renderizarCatalogo();
	});
	$('#filtro-plataforma').on('change', function () {
		estadoCatalogo.plataforma = $(this).val();
		if (estadoCatalogo.plataforma && estadoCatalogo.busqueda) {
			estadoCatalogo.busqueda = '';
			$('#buscador-catalogo').val('');
		}
		estadoCatalogo.pagina = 1;
		sincronizarControles();
		renderizarCatalogo();
	});
	$('#filtro-favoritos').on('click', function () {
		estadoCatalogo.favoritos = !estadoCatalogo.favoritos;
		sincronizarFavoritos();
		estadoCatalogo.pagina = 1;
		renderizarCatalogo();
	});

	$('#paginacion-catalogo').on('click', 'button[data-pagina]', function () {
		const destino = Number($(this).data('pagina'));
		if (!destino || destino === estadoCatalogo.pagina) return;
		const total = Math.max(1, Math.ceil(filtrarCatalogo().length / estadoCatalogo.porPagina));
		if (destino < 1 || destino > total) return;
		estadoCatalogo.pagina = destino;
		renderizarCatalogo();
		$('html, body').animate({ scrollTop: $('.games-section').offset().top }, 300);
	});

	$('#btn-agregar-juego').on('click', function () { abrirModalJuego(null); });

	$('#btn-version-original').on('click', function () {
		if (!confirm('Esto restaurará el catálogo con los datos originales de la API (415 juegos). Los cambios se perderán. ¿Continuar?')) return;
		const $btn = $(this).prop('disabled', true).html('<i class="fa fa-refresh fa-spin" aria-hidden="true"></i> Restaurando...');
		Store.restaurarRespaldo()
			.done(function (respuesta) {
				llenarSelect($('#filtro-genero'), generosConJuegos(), estadoCatalogo.genero, 'Todas las categorías');
				llenarSelect($('#filtro-plataforma'), plataformasConJuegos(), estadoCatalogo.plataforma, 'Todas las plataformas');
				renderizarCatalogo();
				mostrarToast(respuesta.restaurados + ' juegos restaurados desde la versión original.');
			})
			.fail(function () { mostrarToast('El servidor no está disponible.', 'error'); })
			.always(function () { $btn.prop('disabled', false).html('<i class="fa fa-database" aria-hidden="true"></i> Versión original'); });
	});

	$('#btn-subir-bd').on('click', function () {
		if (!confirm('Esto exportará el catálogo actual al archivo de respaldo JSON. ¿Continuar?')) return;
		const $btn = $(this).prop('disabled', true).html('<i class="fa fa-upload fa-spin" aria-hidden="true"></i> Subiendo...');
		Store.exportarRespaldo()
			.done(function (respuesta) {
				mostrarToast(respuesta.exportados + ' juegos subidos a la base de datos.');
			})
			.fail(function () { mostrarToast('El servidor no está disponible.', 'error'); })
			.always(function () { $btn.prop('disabled', false).html('<i class="fa fa-upload" aria-hidden="true"></i> Subir a BD'); });
	});

	sincronizarControles();
	sincronizarFavoritos();
	renderizarCatalogo();
}

/* ============================================================
   5. PÁGINA DETALLE (game-single.html)
   ============================================================ */

function renderizarDetalle() {
	const id = parametroURL('id');
	const juego = id ? Store.buscarPorId(id) : null;

	if (!juego) {
		$('#detalle-contenido').addClass('d-none');
		$('#detalle-vacio').removeClass('d-none');
		return;
	}

	document.title = juego.titulo + ' | Omega Nexus';

	$('#detalle-imagen').attr({
		src: juego.imagen,
		alt: 'Portada del juego ' + juego.titulo
	}).on('error', function () {
		$(this).off('error').attr('src', IMAGEN_RESPALDO);
	});
	$('#detalle-titulo').text(juego.titulo);
	$('#detalle-descripcion').text(juego.descripcion);

	$('#detalle-ficha').html(
		'<li>Género(s)<span>' + escaparHTML(textoGeneros(juego)) + '</span></li>' +
		'<li>Plataforma(s)<span>' + escaparHTML(textoPlataformas(juego)) + '</span></li>' +
		'<li>Desarrollador<span>' + escaparHTML(juego.desarrollador) + '</span></li>' +
		'<li>Lanzamiento<span>' + formatearFecha(juego.fecha) + '</span></li>' +
		'<li>Origen<span>' + (juego.origen === 'api' ? 'API externa' : 'Catálogo local') + '</span></li>'
	);

	$('#detalle-rating').html(
		'<h5><i>Valoración</i><span>' + Number(juego.valoracion).toFixed(1) + '</span> / 5</h5>' +
		'<div class="on-stars on-stars-lg">' + generarEstrellas(Number(juego.valoracion)) + '</div>'
	);

	$('#detalle-jugar-wrap').toggleClass('d-none', !juego.juego_url);
	$('#detalle-jugar').attr('href', juego.juego_url || '#');

	$('#btn-editar-detalle').off('click').on('click', function () { abrirModalJuego(juego); });
	$('#btn-eliminar-detalle').off('click').on('click', function () { eliminarJuego(juego.id); });
	const esFav = Store.esFavorito(juego.id);
	$('#btn-favorito-detalle')
		.toggleClass('activo', esFav)
		.find('span').text(esFav ? 'En favoritos' : 'Agregar a favoritos')
		.end().off('click').on('click', function () {
			const activo = Store.alternarFavorito(juego.id);
			$(this).toggleClass('activo', activo)
				.find('span').text(activo ? 'En favoritos' : 'Agregar a favoritos');
			mostrarToast(activo ? 'Agregado a favoritos.' : 'Quitado de favoritos.');
		});

	const relacionados = Store.obtenerCatalogo()
		.filter(function (j) {
			if (String(j.id) === String(juego.id)) return false;
			return generosDe(j).some(function (g) {
				return generosDe(juego).indexOf(g) !== -1;
			});
		})
		.slice(0, 4);
	const $rel = $('#detalle-relacionados').empty();
	if (relacionados.length) {
		$('#detalle-relacionados-bloque').removeClass('d-none');
		relacionados.forEach(function (r) {
			$rel.append(
				'<a href="game-single.html?id=' + encodeURIComponent(r.id) + '" class="on-related-card">' +
					'<img src="' + escaparHTML(r.imagen) + '"' +
						' alt="Portada de ' + escaparHTML(r.titulo) + '"' +
						' onerror="this.onerror=null;this.src=\'' + IMAGEN_RESPALDO + '\'">' +
					'<div class="on-related-card-info">' +
						'<h5>' + escaparHTML(r.titulo) + '</h5>' +
						'<span class="on-related-genre">' + escaparHTML(primerGenero(r)) + '</span>' +
					'</div>' +
				'</a>'
			);
		});
	} else {
		$('#detalle-relacionados-bloque').addClass('d-none');
	}
}

function initDetalle() {
	window.PaginaActual = 'detalle';
	renderizarDetalle();
}

/* ============================================================
   6. PÁGINA RESEÑAS (review.html) - Solo valoración > 4.8
   ============================================================ */

function renderizarResenas() {
	let lista = Store.obtenerCatalogo();

	lista = lista.filter(function (j) { return Number(j.valoracion) > 4.8; });
	lista.sort(function (a, b) { return b.valoracion - a.valoracion; });

	const $cont = $('#lista-resenas').empty();
	if (!lista.length) {
		$cont.html('<p class="text-white">No hay reseñas con valoración mayor a 4.5.</p>');
		return;
	}

	lista.forEach(function (juego) {
		$cont.append(
			'<div class="review-item on-card" data-id="' + escaparHTML(juego.id) + '">' +
				'<div class="row">' +
					'<div class="col-lg-4">' +
						'<div class="review-pic">' +
							'<img src="' + escaparHTML(juego.imagen) + '" alt="Portada de ' + escaparHTML(juego.titulo) + '"' +
								' onerror="this.onerror=null;this.src=\'' + IMAGEN_RESPALDO + '\'">' +
						'</div>' +
					'</div>' +
					'<div class="col-lg-8">' +
						'<div class="review-content text-box text-white">' +
							'<div class="rating"><h5><i>Valoración</i><span>' +
								Number(juego.valoracion).toFixed(1) + '</span> / 5</h5></div>' +
							'<div class="top-meta">Hecha ' + formatearFecha(juego.fecha) + ' en los juegos tipo ' +
								'<a href="games.html?genero=' + encodeURIComponent(primerGenero(juego)) + '">' +
								escaparHTML(primerGenero(juego)) + '</a></div>' +
							'<h3>' + escaparHTML(juego.titulo) + '</h3>' +
							'<p>' + escaparHTML(juego.descripcion) + '</p>' +
							'<div class="on-card-actions">' +
								'<a href="game-single.html?id=' + encodeURIComponent(juego.id) +
									'" class="read-more">Leer reseña completa <img src="img/icons/double-arrow.png" alt=""/></a>' +
								'<button type="button" class="on-icon-btn" data-accion="editar" aria-label="Editar juego">' +
									'<i class="fa fa-pencil" aria-hidden="true"></i></button>' +
								'<button type="button" class="on-icon-btn on-peligro" data-accion="eliminar" aria-label="Eliminar juego">' +
									'<i class="fa fa-trash" aria-hidden="true"></i></button>' +
							'</div>' +
						'</div>' +
					'</div>' +
				'</div>' +
			'</div>'
		);
	});
}

function initResenas() {
	window.PaginaActual = 'resenas';
	renderizarResenas();
}

/* ============================================================
   7. PÁGINA NOVEDADES (blog.html)
   ============================================================ */

function renderizarNovedades() {
	const lista = Store.obtenerCatalogo().slice()
		.sort(function (a, b) { return String(b.fecha).localeCompare(String(a.fecha)); })
		.slice(0, 6);

	const $cont = $('#lista-novedades').empty();
	lista.forEach(function (juego) {
		$cont.append(
			'<div class="blog-item on-card" data-id="' + escaparHTML(juego.id) + '">' +
				'<div class="blog-thumb">' +
					'<img src="' + escaparHTML(juego.imagen) + '" alt="Portada de ' + escaparHTML(juego.titulo) + '"' +
						' onerror="this.onerror=null;this.src=\'' + IMAGEN_RESPALDO + '\'">' +
				'</div>' +
				'<div class="blog-text text-box text-white">' +
					'<div class="top-meta">' + formatearFecha(juego.fecha) + ' / en ' +
						'<a href="games.html?genero=' + encodeURIComponent(primerGenero(juego)) + '">' +
						escaparHTML(primerGenero(juego)) + '</a></div>' +
					'<h3>' + escaparHTML(juego.titulo) + '</h3>' +
					'<p>' + escaparHTML(juego.descripcion) + '</p>' +
					'<div class="on-card-actions">' +
						'<a href="game-single.html?id=' + encodeURIComponent(juego.id) +
							'" class="read-more">Ver más <img src="img/icons/double-arrow.png" alt=""/></a>' +
						'<button type="button" class="on-icon-btn" data-accion="editar" aria-label="Editar juego">' +
							'<i class="fa fa-pencil" aria-hidden="true"></i></button>' +
						'<button type="button" class="on-icon-btn on-peligro" data-accion="eliminar" aria-label="Eliminar juego">' +
							'<i class="fa fa-trash" aria-hidden="true"></i></button>' +
					'</div>' +
				'</div>' +
			'</div>'
		);
	});
}

function initNovedades() {
	window.PaginaActual = 'novedades';

	renderizarNovedades();
}

/* ============================================================
   8. PÁGINA INICIO (index.html)
   ============================================================ */

function initInicio() {
	window.PaginaActual = 'inicio';
	const catalogo = Store.obtenerCatalogo();

	const $cats = $('#inicio-categorias').empty();
	generosDelCatalogo().forEach(function (genero) {
		$cats.append('<li><a href="games.html?genero=' + encodeURIComponent(genero) + '">' +
			escaparHTML(genero) + '</a></li>');
	});

	const totalApi = catalogo.filter(function (j) { return j.origen === 'api'; }).length;
	$('#stat-total').text(catalogo.length);
	$('#stat-api').text(totalApi);
	$('#stat-generos').text(generosDelCatalogo().length);
}

/* ============================================================
   9. PÁGINA CONTACTO (contact.html)
   ============================================================ */

function initContacto() {
	window.PaginaActual = 'contacto';

	$('#form-contacto').on('submit', function (evento) {
		evento.preventDefault();

		if (!this.checkValidity()) {
			$(this).addClass('was-validated');
			return;
		}

		Store.agregarMensaje({
			nombre: $.trim($('#contacto-nombre').val()),
			email: $.trim($('#contacto-email').val()),
			asunto: $.trim($('#contacto-asunto').val()),
			mensaje: $.trim($('#contacto-mensaje').val()),
			fecha: new Date().toISOString()
		});

		this.reset();
		$(this).removeClass('was-validated');
		$('#contacto-exito').removeClass('d-none');
		mostrarToast('¡Mensaje enviado! Te responderemos pronto.');
		setTimeout(function () { $('#contacto-exito').addClass('d-none'); }, 6000);
	});
}

/* ============================================================
   10. BOLETÍN DE NOTICIAS
   ============================================================ */

$(document).on('submit', '.newsletter-form', function (evento) {
	evento.preventDefault();
	const $input = $(this).find('input[type="email"]');
	const email = $.trim($input.val());

	if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
		mostrarToast('Ingresa un correo electrónico válido.', 'error');
		return;
	}

	Store.agregarBoletin(email);
	$input.val('');
	mostrarToast('¡Suscripción registrada! Gracias por unirte.');
});

/* ============================================================
   11. ARRANQUE GENERAL
   ============================================================ */

$(function () {
	/* Vinculación del formulario CRUD (existe en todas las páginas) */
	$(document).on('submit', '#form-juego', guardarFormularioJuego);

	Store.inicializarCatalogo();

	Store.cargarDesdeBaseDatos()
		.done(function () {
			if (window.PaginaActual === 'inicio') initInicio();
			if (window.PaginaActual === 'catalogo') {
				llenarSelect($('#filtro-genero'), generosConJuegos(), estadoCatalogo.genero, 'Todas las categorías');
				llenarSelect($('#filtro-plataforma'), plataformasConJuegos(), estadoCatalogo.plataforma, 'Todas las plataformas');
				renderizarCatalogo();
			}
			if (window.PaginaActual === 'detalle') renderizarDetalle();
			if (window.PaginaActual === 'resenas') renderizarResenas();
			if (window.PaginaActual === 'novedades') renderizarNovedades();
		})
		.fail(function () {
			/* Sin backend se conserva el caché local */
		});

	switch ($('body').data('page')) {
		case 'inicio': initInicio(); break;
		case 'catalogo': initCatalogo(); break;
		case 'detalle': initDetalle(); break;
		case 'resenas': initResenas(); break;
		case 'novedades': initNovedades(); break;
		case 'contacto': initContacto(); break;
	}
});
