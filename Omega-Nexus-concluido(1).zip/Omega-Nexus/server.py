"""Backend local de Omega Nexus: SQLite + API HTTP sin dependencias externas."""

import json
import sqlite3
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

ROOT = Path(__file__).resolve().parent
DATABASE = ROOT / "omega_nexus.db"
ORIGINAL = ROOT / "js" / "api-original.json"
RESPALDO = ROOT / "js" / "api-respaldo.json"
HOST = "127.0.0.1"
PORT = 8000


def split_values(value, default=""):
    """Separa un valor que puede contener varios elementos separados por coma."""
    if not value:
        return [default] if default else []
    return [v.strip() for v in str(value).split(",") if v.strip()]


def map_original_game(item):
    """Convierte un elemento del formato original de la API FreeToGame
    al esquema interno del catálogo."""
    game_id = item.get("id")
    return {
        "api_id": "api-" + str(game_id),
        "titulo": item.get("title", ""),
        "generos": split_values(item.get("genre")) or ["Sin categoría"],
        "plataformas": split_values(item.get("platform")) or ["Sin plataforma"],
        "fecha": item.get("release_date", ""),
        "valoracion": round(((int(game_id) % 20) / 10 + 3) * 10) / 10,
        "descripcion": item.get("short_description", ""),
        "desarrollador": item.get("developer") or "Desconocido",
        "imagen": item.get("thumbnail", ""),
        "juego_url": item.get("game_url", ""),
        "origen": "api",
    }


def read_original():
    with ORIGINAL.open("r", encoding="utf-8") as file:
        return [map_original_game(item) for item in json.load(file)]


def read_respaldo():
    with RESPALDO.open("r", encoding="utf-8") as file:
        return json.load(file)


def connection():
    database = sqlite3.connect(DATABASE)
    database.row_factory = sqlite3.Row
    database.execute("PRAGMA foreign_keys = ON")
    return database


def setup_database():
    database = connection()
    database.execute(
        """CREATE TABLE IF NOT EXISTS juegos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            api_id TEXT,
            titulo TEXT NOT NULL,
            fecha TEXT,
            valoracion REAL NOT NULL DEFAULT 0,
            descripcion TEXT,
            desarrollador TEXT,
            imagen TEXT,
            juego_url TEXT,
            origen TEXT NOT NULL DEFAULT 'local',
            actualizado_en TEXT NOT NULL
        )"""
    )
    database.execute(
        """CREATE TABLE IF NOT EXISTS juegos_categorias (
            juego_id INTEGER NOT NULL,
            genero TEXT NOT NULL,
            FOREIGN KEY (juego_id) REFERENCES juegos(id) ON DELETE CASCADE
        )"""
    )
    database.execute(
        """CREATE TABLE IF NOT EXISTS juegos_plataformas (
            juego_id INTEGER NOT NULL,
            plataforma TEXT NOT NULL,
            FOREIGN KEY (juego_id) REFERENCES juegos(id) ON DELETE CASCADE
        )"""
    )
    # Permisos para borrado en cascada
    database.execute("PRAGMA foreign_keys = ON")
    database.commit()

    # Migración: si la tabla vieja conserva columnas genero/plataforma (esquema previo),
    # se reconstruye con el esquema normalizado desde los datos de la API.
    cols = [r[1] for r in database.execute("PRAGMA table_info(juegos)")]
    if "genero" in cols or "plataforma" in cols:
        database.execute("DROP TABLE IF EXISTS juegos_categorias")
        database.execute("DROP TABLE IF EXISTS juegos_plataformas")
        database.execute("DROP TABLE IF EXISTS juegos")
        database.commit()
        database.execute(
            """CREATE TABLE juegos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                api_id TEXT,
                titulo TEXT NOT NULL,
                fecha TEXT,
                valoracion REAL NOT NULL DEFAULT 0,
                descripcion TEXT,
                desarrollador TEXT,
                imagen TEXT,
                juego_url TEXT,
                origen TEXT NOT NULL DEFAULT 'local',
                actualizado_en TEXT NOT NULL
            )"""
        )
        database.execute(
            """CREATE TABLE juegos_categorias (
                juego_id INTEGER NOT NULL,
                genero TEXT NOT NULL,
                FOREIGN KEY (juego_id) REFERENCES juegos(id) ON DELETE CASCADE
            )"""
        )
        database.execute(
            """CREATE TABLE juegos_plataformas (
                juego_id INTEGER NOT NULL,
                plataforma TEXT NOT NULL,
                FOREIGN KEY (juego_id) REFERENCES juegos(id) ON DELETE CASCADE
            )"""
        )
        database.commit()
        save_games(database, read_original())
    elif database.execute("SELECT COUNT(*) FROM juegos").fetchone()[0] == 0:
        save_games(database, read_original())
    database.close()


def save_games(database, games):
    timestamp = datetime.now(timezone.utc).isoformat()
    database.execute("DELETE FROM juegos")
    database.execute("DELETE FROM sqlite_sequence WHERE name='juegos'")
    normalized_games = []
    for game in games:
        normalized_games.append({
            "api_id": game.get("api_id", ""),
            "titulo": game.get("titulo", ""),
            "fecha": game.get("fecha", ""),
            "valoracion": game.get("valoracion", 0),
            "descripcion": game.get("descripcion", ""),
            "desarrollador": game.get("desarrollador", ""),
            "imagen": game.get("imagen", ""),
            "juego_url": game.get("juego_url", ""),
            "origen": game.get("origen", "local"),
            "actualizado_en": timestamp,
            "generos": game.get("generos") or normalizar_valores(game.get("genero")),
            "plataformas": game.get("plataformas") or normalizar_valores(game.get("plataforma")),
        })
    for game in normalized_games:
        cursor = database.execute(
            """INSERT INTO juegos
            (api_id, titulo, fecha, valoracion, descripcion,
             desarrollador, imagen, juego_url, origen, actualizado_en)
            VALUES (:api_id, :titulo, :fecha, :valoracion, :descripcion,
                    :desarrollador, :imagen, :juego_url, :origen,
                    :actualizado_en)""",
            game,
        )
        juego_id = cursor.lastrowid
        for genero in game["generos"]:
            if genero:
                database.execute(
                    "INSERT INTO juegos_categorias (juego_id, genero) VALUES (?, ?)",
                    (juego_id, genero))
        for plataforma in game["plataformas"]:
            if plataforma:
                database.execute(
                    "INSERT INTO juegos_plataformas (juego_id, plataforma) VALUES (?, ?)",
                    (juego_id, plataforma))
    database.commit()


def normalizar_valores(valor):
    """Interpreta un string o lista simple en lista de valores."""
    if isinstance(valor, list):
        return [v for v in valor if v]
    return split_values(valor)


def all_games(database):
    rows = database.execute(
        "SELECT id, api_id, titulo, fecha, valoracion, "
        "descripcion, desarrollador, imagen, juego_url, origen FROM juegos ORDER BY titulo"
    ).fetchall()
    catalog = []
    for row in rows:
        juego = dict(row)
        generos = database.execute(
            "SELECT genero FROM juegos_categorias WHERE juego_id=? ORDER BY genero",
            (juego["id"],),
        ).fetchall()
        plataformas = database.execute(
            "SELECT plataforma FROM juegos_plataformas WHERE juego_id=? ORDER BY plataforma",
            (juego["id"],),
        ).fetchall()
        juego["generos"] = [g["genero"] for g in generos]
        juego["plataformas"] = [p["plataforma"] for p in plataformas]
        catalog.append(juego)
    return catalog


def export_respaldo():
    """Reemplaza api-respaldo.json con el contenido actual de la base de datos."""
    database = connection()
    juegos = all_games(database)
    database.close()
    RESPALDO.write_text(
        json.dumps(juegos, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return len(juegos)


class RequestHandler(BaseHTTPRequestHandler):
    def send_json(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def read_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        return json.loads(self.rfile.read(length).decode("utf-8"))

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, PUT, POST, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/catalogo":
            database = connection()
            games = all_games(database)
            database.close()
            self.send_json(200, games)
            return
        if path == "/api/estado":
            database = connection()
            count = database.execute("SELECT COUNT(*) FROM juegos").fetchone()[0]
            database.close()
            self.send_json(200, {"base_datos": str(DATABASE.name), "juegos": count})
            return
        self.serve_static(path)

    def do_PUT(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if path == "/api/catalogo":
            games = self.read_json()
            if not isinstance(games, list):
                self.send_json(400, {"error": "El catálogo debe ser un arreglo JSON"})
                return
            database = connection()
            save_games(database, games)
            database.close()
            self.send_json(200, {"guardados": len(games)})
            return
        if path.startswith("/api/juego/"):
            try:
                juego_id = int(path.split("/")[-1])
            except ValueError:
                self.send_json(400, {"error": "ID inválido"})
                return
            datos = self.read_json()
            database = connection()
            database.execute("PRAGMA foreign_keys = ON")
            timestamp = datetime.now(timezone.utc).isoformat()
            database.execute(
                """UPDATE juegos SET titulo=:titulo, fecha=:fecha, valoracion=:valoracion,
                   descripcion=:descripcion, desarrollador=:desarrollador,
                   imagen=:imagen, juego_url=:juego_url, origen=:origen,
                   actualizado_en=:actualizado_en
                   WHERE id=:id""",
                {"titulo": datos.get("titulo", ""),
                 "fecha": datos.get("fecha", ""),
                 "valoracion": datos.get("valoracion", 0),
                 "descripcion": datos.get("descripcion", ""),
                 "desarrollador": datos.get("desarrollador", ""),
                 "imagen": datos.get("imagen", ""),
                 "juego_url": datos.get("juego_url", ""),
                 "origen": datos.get("origen", "local"),
                 "actualizado_en": timestamp,
                 "id": juego_id}
            )
            database.execute("DELETE FROM juegos_categorias WHERE juego_id=?", (juego_id,))
            database.execute("DELETE FROM juegos_plataformas WHERE juego_id=?", (juego_id,))
            for genero in normalizar_valores(datos.get("generos") or datos.get("genero")):
                database.execute(
                    "INSERT INTO juegos_categorias (juego_id, genero) VALUES (?, ?)",
                    (juego_id, genero))
            for plataforma in normalizar_valores(datos.get("plataformas") or datos.get("plataforma")):
                database.execute(
                    "INSERT INTO juegos_plataformas (juego_id, plataforma) VALUES (?, ?)",
                    (juego_id, plataforma))
            database.commit()
            database.close()
            self.send_json(200, {"ok": True})
            return
        self.send_json(404, {"error": "Ruta no encontrada"})

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if path == "/api/juego":
            datos = self.read_json()
            database = connection()
            database.execute("PRAGMA foreign_keys = ON")
            timestamp = datetime.now(timezone.utc).isoformat()
            cursor = database.execute(
                """INSERT INTO juegos
                (api_id, titulo, fecha, valoracion, descripcion, desarrollador,
                 imagen, juego_url, origen, actualizado_en)
                VALUES (:api_id, :titulo, :fecha, :valoracion, :descripcion,
                        :desarrollador, :imagen, :juego_url, :origen,
                        :actualizado_en)""",
                {"api_id": datos.get("api_id", ""),
                 "titulo": datos.get("titulo", ""),
                 "fecha": datos.get("fecha", ""),
                 "valoracion": datos.get("valoracion", 0),
                 "descripcion": datos.get("descripcion", ""),
                 "desarrollador": datos.get("desarrollador", ""),
                 "imagen": datos.get("imagen", ""),
                 "juego_url": datos.get("juego_url", ""),
                 "origen": datos.get("origen", "local"),
                 "actualizado_en": timestamp}
            )
            nuevo_id = cursor.lastrowid
            for genero in normalizar_valores(datos.get("generos") or datos.get("genero")):
                database.execute(
                    "INSERT INTO juegos_categorias (juego_id, genero) VALUES (?, ?)",
                    (nuevo_id, genero))
            for plataforma in normalizar_valores(datos.get("plataformas") or datos.get("plataforma")):
                database.execute(
                    "INSERT INTO juegos_plataformas (juego_id, plataforma) VALUES (?, ?)",
                    (nuevo_id, plataforma))
            database.commit()
            database.close()
            self.send_json(201, {"id": nuevo_id})
            return
        if path == "/api/exportar-respaldo":
            self.send_json(200, {"exportados": export_respaldo()})
            return
        if path == "/api/restaurar-respaldo":
            database = connection()
            games = read_original()
            save_games(database, games)
            database.close()
            self.send_json(200, {"restaurados": len(games), "catalogo": games})
            return
        self.send_json(404, {"error": "Ruta no encontrada"})

    def do_DELETE(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if path.startswith("/api/juego/"):
            try:
                juego_id = int(path.split("/")[-1])
            except ValueError:
                self.send_json(400, {"error": "ID inválido"})
                return
            database = connection()
            database.execute("PRAGMA foreign_keys = ON")
            database.execute("DELETE FROM juegos WHERE id=?", (juego_id,))
            database.commit()
            database.close()
            self.send_json(200, {"ok": True})
            return
        self.send_json(404, {"error": "Ruta no encontrada"})

    def serve_static(self, path):
        relative = "index.html" if path in ("", "/") else path.lstrip("/")
        file_path = (ROOT / relative).resolve()
        if ROOT not in file_path.parents and file_path != ROOT:
            self.send_error(403)
            return
        if not file_path.is_file():
            self.send_error(404)
            return
        content_type = "text/html; charset=utf-8"
        if file_path.suffix == ".js":
            content_type = "text/javascript; charset=utf-8"
        elif file_path.suffix == ".css":
            content_type = "text/css; charset=utf-8"
        elif file_path.suffix == ".json":
            content_type = "application/json; charset=utf-8"
        data = file_path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, format_string, *args):
        print("%s - %s" % (self.address_string(), format_string % args))


if __name__ == "__main__":
    setup_database()
    print("Omega Nexus disponible en http://%s:%s" % (HOST, PORT))
    ThreadingHTTPServer((HOST, PORT), RequestHandler).serve_forever()
